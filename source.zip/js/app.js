import * as core from './core.js';
import { LEVELS, ACTIVITIES } from './registry.js';
import { loaders } from './loaders.js';
const { h, say, sfx, confetti, store, settings, setSound, setVoiceOn, stopSpeaking, sleep } = core;

const app = document.getElementById('app');
let current = null; // { destroy }
let progress = store.get('progress', {}); // id -> stars
const saveProgress = () => store.set('progress', progress);

// ------------- routing -------------
function route() {
  const hash = location.hash || '#/';
  teardown();
  if (hash.startsWith('#/play/')) return playActivity(decodeURIComponent(hash.slice(7)));
  if (hash === '#/grownups') return grownups();
  return home();
}
function teardown() {
  try { current?.destroy?.(); } catch (e) { console.error(e); }
  current = null; stopSpeaking(); app.className = ''; app.replaceChildren();
}
window.addEventListener('hashchange', route);

// ------------- owl guide (original character) -------------
export function owl(size = 84) {
  return h('svg', { viewBox: '0 0 100 100', width: size, height: size, class: 'owl', 'aria-hidden': 'true', html: `
    <ellipse cx="50" cy="60" rx="30" ry="32" fill="#a78bfa"/>
    <ellipse cx="50" cy="68" rx="19" ry="21" fill="#ede9fe"/>
    <polygon points="26,34 30,14 42,28" fill="#8b5cf6"/><polygon points="74,34 70,14 58,28" fill="#8b5cf6"/>
    <circle cx="38" cy="45" r="13" fill="#fff"/><circle cx="62" cy="45" r="13" fill="#fff"/>
    <circle cx="38" cy="46" r="6" fill="#2b2d42"/><circle cx="62" cy="46" r="6" fill="#2b2d42"/>
    <circle cx="40" cy="44" r="2" fill="#fff"/><circle cx="64" cy="44" r="2" fill="#fff"/>
    <polygon points="45,53 55,53 50,62" fill="#ffb703"/>
    <ellipse cx="40" cy="92" rx="8" ry="4" fill="#ffb703"/><ellipse cx="60" cy="92" rx="8" ry="4" fill="#ffb703"/>` });
}

// ------------- home / map -------------
function home() {
  app.className = 'page-home';
  const done = ACTIVITIES.filter((a) => progress[a.id]).length;
  const next = ACTIVITIES.find((a) => !progress[a.id]) || null;
  const header = h('header', { class: 'hero' },
    h('div', { class: 'hero-owl' }, owl(96)),
    h('div', {},
      h('h1', {}, 'Nilaa Learns Math'),
      h('p', { class: 'tag' }, 'Little games for curious minds — from easy to tricky.'),
      h('p', { class: 'count' }, `⭐ ${Object.values(progress).reduce((s, n) => s + n, 0)} stars · ${done} of ${ACTIVITIES.length} games played`)),
    h('div', { class: 'hero-btns' },
      toggle('🗣️', 'Voice', () => settings.voice, setVoiceOn),
      toggle('🔊', 'Sound', () => settings.sound, setSound),
      h('a', { class: 'btn small', href: '#/grownups' }, 'For grown-ups')));
  const map = h('main', { class: 'map' });
  for (const lv of LEVELS) {
    const acts = ACTIVITIES.filter((a) => a.level === lv.n);
    map.append(h('section', { class: `level lv${lv.n}` },
      h('h2', {}, h('span', { class: 'lv-emoji' }, lv.emoji), ` Level ${lv.n}: ${lv.name}`, h('small', {}, lv.blurb)),
      h('div', { class: 'tiles' }, acts.map((a) => {
        const idx = ACTIVITIES.indexOf(a) + 1;
        return h('a', { class: `tile ${progress[a.id] ? 'done' : ''} ${next && next.id === a.id ? 'next' : ''}`, href: `#/play/${a.id}`, onclick: () => sfx('pop') },
          h('span', { class: 'num' }, idx),
          h('span', { class: 'big' }, a.emoji),
          h('strong', {}, a.title),
          h('span', { class: 'sub' }, a.blurb),
          h('span', { class: 'stars' }, progress[a.id] ? '⭐'.repeat(progress[a.id]) : (next && next.id === a.id ? 'Play next!' : '')));
      }))));
  }
  app.append(header, map, h('footer', { class: 'foot' }, 'Inspired by the maths circle described in “Math from Three to Seven” by Alexander Zvonkin. Original games, drawings and words.'));
}

function toggle(emoji, label, get, set) {
  const b = h('button', { class: 'btn small toggle', 'aria-pressed': String(get()), title: label }, `${emoji} ${label}: ${get() ? 'on' : 'off'}`);
  b.addEventListener('click', () => { set(!get()); b.setAttribute('aria-pressed', String(get())); b.textContent = `${emoji} ${label}: ${get() ? 'on' : 'off'}`; sfx('tap'); });
  return b;
}

// ------------- activity frame -------------
async function playActivity(id) {
  const meta = ACTIVITIES.find((a) => a.id === id);
  if (!meta) { location.hash = '#/'; return; }
  app.className = `page-play lv${meta.level}`;
  const banner = h('div', { class: 'banner', 'aria-live': 'polite' });
  const bannerText = h('span', {});
  const replay = h('button', { class: 'icon-btn', title: 'Hear it again', 'aria-label': 'Hear it again', onclick: () => say(bannerText.textContent) }, '🔈');
  banner.append(h('div', { class: 'banner-owl' }, owl(48)), bannerText, replay);
  const dots = h('div', { class: 'dots' });
  const stage = h('div', { class: 'stage' });
  const watchBtn = h('button', { class: 'btn small watch', hidden: true }, '👀 Watch');
  const bar = h('div', { class: 'bar' },
    h('a', { class: 'btn small', href: '#/' }, '← Map'),
    h('div', { class: 'bar-title' }, `${meta.emoji} ${meta.title}`),
    watchBtn,
    h('button', { class: 'btn small', onclick: () => { sfx('tap'); mount(); } }, '↻ Again'),
    toggle('🗣️', 'Voice', () => settings.voice, setVoiceOn));
  app.append(bar, banner, stage, dots);

  let demoFn = null; let running = false; let gen = 0; let styleEls = [];
  watchBtn.addEventListener('click', async () => {
    if (!demoFn || running) return; running = true; watchBtn.disabled = true; stage.classList.add('demo-running');
    const g = gen;
    try { await demoFn(); } catch (e) { console.error('demo error', e); }
    if (g === gen) { running = false; watchBtn.disabled = false; stage.classList.remove('demo-running'); }
  });

  let inst = null;
  async function mount() {
    gen++; running = false; watchBtn.disabled = false; stage.classList.remove('demo-running');
    try { inst?.destroy?.(); } catch (e) { console.error(e); }
    stopSpeaking(); stage.replaceChildren(); dots.replaceChildren(); demoFn = null; watchBtn.hidden = true; bannerText.textContent = '';
    let mod;
    try { mod = (await loaders[id]()).default; }
    catch (e) { console.error(e); stage.append(h('p', { class: 'err' }, 'This game is still being made. Please come back soon!')); return; }
    const api = {
      root: stage, meta, ...core,
      prompt(text) { bannerText.textContent = text; banner.classList.remove('good', 'try'); banner.classList.add('pulse'); setTimeout(() => banner.classList.remove('pulse'), 600); return say(text); },
      cheer(text) { bannerText.textContent = text || 'Well done!'; banner.classList.remove('try'); banner.classList.add('good'); sfx('good'); return say(text || 'Well done!'); },
      nudge(text) { bannerText.textContent = text || 'Hmm, let us try again.'; banner.classList.remove('good'); banner.classList.add('try'); sfx('oops'); return say(text || 'Hmm, let us try again.'); },
      stage(i, n) { dots.replaceChildren(...Array.from({ length: n }, (_, k) => h('span', { class: `dot ${k < i ? 'full' : ''} ${k === i ? 'now' : ''}` }))); },
      setDemo(fn) { demoFn = fn; watchBtn.hidden = !fn; },
      css(text) { const s = h('style', {}, text); document.head.append(s); styleEls.push(s); },
      finish() {
        const stars = 3; progress[id] = Math.max(progress[id] || 0, stars); saveProgress();
        sfx('win'); confetti(document.body, 60);
        const idx = ACTIVITIES.indexOf(meta); const nextAct = ACTIVITIES[idx + 1];
        const ov = h('div', { class: 'overlay' }, h('div', { class: 'card' },
          owl(80), h('h2', {}, 'Hooray! You did it!'), h('div', { class: 'bigstars' }, '⭐⭐⭐'),
          h('div', { class: 'row' },
            h('button', { class: 'btn', onclick: () => { ov.remove(); mount(); } }, '↻ Play again'),
            nextAct ? h('a', { class: 'btn primary', href: `#/play/${nextAct.id}` }, `Next: ${nextAct.title} →`) : h('a', { class: 'btn primary', href: '#/' }, 'Back to the map'),
            h('a', { class: 'btn', href: '#/' }, 'Map'))));
        app.append(ov); say('Hooray! You did it!');
      },
    };
    document.head.append(...[]);
    try { inst = (await mod.start(api)) || {}; }
    catch (e) { console.error(e); stage.replaceChildren(h('p', { class: 'err' }, 'Oops, something went wrong in this game.')); }
    current = { destroy() { try { inst?.destroy?.(); } catch (e) { console.error(e); } styleEls.forEach((s) => s.remove()); styleEls = []; } };
  }
  await mount();
}

// ------------- grown-ups page -------------
async function grownups() {
  app.className = 'page-grownups';
  const wrap = h('main', { class: 'grown' },
    h('a', { class: 'btn small', href: '#/' }, '← Back to the map'),
    h('h1', {}, 'For grown-ups'),
    h('p', {}, 'Nilaa Learns Math is a set of small, original games inspired by the activities of a real preschool maths circle, described in Alexander Zvonkin’s book “Math from Three to Seven”. The games run in any browser, need no sign-in, and store only stars on this device.'),
    h('p', {}, 'Tips: sit alongside, let her try before you explain, and use the “Watch” button only when she is stuck. There are no scores to lose and no timers — mistakes simply bounce back. Turn Voice off on the map if you prefer to read aloud yourself.'),
    h('div', { class: 'notes' }, h('p', {}, 'Loading notes…')));
  app.append(wrap);
  const notes = wrap.querySelector('.notes'); notes.replaceChildren();
  for (const lv of LEVELS) {
    notes.append(h('h2', {}, `Level ${lv.n}: ${lv.name} — ${lv.blurb}`));
    for (const a of ACTIVITIES.filter((x) => x.level === lv.n)) {
      let note = '';
      try { note = (await loaders[a.id]()).default.parentNote || ''; } catch { note = '(coming soon)'; }
      notes.append(h('div', { class: 'note' }, h('h3', {}, `${a.emoji} ${a.title}`), h('p', {}, note || a.blurb)));
    }
  }
  notes.append(h('p', { class: 'small' }, 'This site is an independent educational project and is not affiliated with the book’s author or publisher. The games, drawings and wording are original; please read the book itself for the full story and the children’s own words.'));
}

route();
