import { h, sleep, shuffle, rand, pick, sfx, COLORS } from '../core.js';

// "Build the Picture": tangram-like fitting on a grid.
// Geometry model: every unit cell is cut by both diagonals into 4 quarter-triangles
// (q: 0 = top, 1 = right, 2 = bottom, 3 = left). Every piece and every silhouette is an
// exact set of quarters "x,y,q", so "does it fit?" and "is it full?" are exact set checks.

const ID = 'build-from-picture';
const ALL = [0, 1, 2, 3];
const BASE = {
  sq: [[0, 0, ALL]],
  dom: [[0, 0, ALL], [1, 0, ALL]],
  bar3: [[0, 0, ALL], [1, 0, ALL], [2, 0, ALL]],
  big: [[0, 0, ALL], [1, 0, ALL], [0, 1, ALL], [1, 1, ALL]],
  tri: [[0, 0, [3, 2]]],                                   // right angle bottom-left
  btri: [[0, 0, [3, 2]], [0, 1, ALL], [1, 1, [3, 2]]],     // legs of 2, right angle bottom-left
  roof: [[0, 0, [1, 2]], [1, 0, [3, 2]]],                  // 2 wide, 1 tall, point up
};
const K = (x, y, q) => `${x},${y},${q}`;
const parseK = (k) => k.split(',').map(Number);
const cmpK = (a, b) => { const [ax, ay, aq] = parseK(a), [bx, by, bq] = parseK(b); return ay - by || ax - bx || aq - bq; };

function normQ(qs) {
  const mx = Math.min(...qs.map((t) => t[0])), my = Math.min(...qs.map((t) => t[1]));
  return qs.map(([x, y, q]) => [x - mx, y - my, q]).sort((a, b) => a[1] - b[1] || a[0] - b[0] || a[2] - b[2]);
}
// 90 degrees clockwise on screen (y down): (x, y) -> (-y, x); top->right->bottom->left.
const rotQ = (qs) => normQ(qs.map(([x, y, q]) => [-y - 1, x, (q + 1) % 4]));
const SH = {};
for (const [type, def] of Object.entries(BASE)) {
  const rots = [normQ(def.flatMap(([x, y, qs]) => qs.map((q) => [x, y, q])))];
  for (let i = 1; i < 4; i++) rots.push(rotQ(rots[i - 1]));
  const sig = rots.map((r) => JSON.stringify(r));
  const uniq = [0, 1, 2, 3].filter((i) => sig.indexOf(sig[i]) === i);
  const dims = rots.map((r) => ({ w: Math.max(...r.map((t) => t[0])) + 1, h: Math.max(...r.map((t) => t[1])) + 1 }));
  SH[type] = { rots, uniq, dims, max: Math.max(dims[0].w, dims[0].h) };
}
const sameRot = (type, a, b) => a === b || JSON.stringify(SH[type].rots[a]) === JSON.stringify(SH[type].rots[b]);
const keysAt = (type, rot, x, y) => SH[type].rots[rot].map(([a, b, q]) => K(a + x, b + y, q));

// ---- geometry -> SVG (units: 1 = one cell) ----
function quarterPts(x, y, q) {
  const TL = [x, y], TR = [x + 1, y], BR = [x + 1, y + 1], BL = [x, y + 1], C = [x + 0.5, y + 0.5];
  const [a, b] = [[TL, TR], [TR, BR], [BR, BL], [BL, TL]][q];
  return [a, b, C];
}
function fillD(keys) {
  return keys.map((k) => 'M' + quarterPts(...parseK(k)).map((p) => p.join(',')).join('L') + 'Z').join('');
}
function outlineD(keys) {
  const cnt = new Map();
  for (const k of keys) {
    const [a, b, c] = quarterPts(...parseK(k));
    for (const [p, r] of [[a, b], [b, c], [c, a]]) {
      const e = [p.join(','), r.join(',')].sort().join('|');
      cnt.set(e, (cnt.get(e) || 0) + 1);
    }
  }
  const adj = new Map(); const edges = [];
  for (const [e, n] of cnt) if (n === 1) edges.push(e.split('|'));
  edges.forEach(([p, r], i) => { for (const v of [p, r]) { if (!adj.has(v)) adj.set(v, []); adj.get(v).push(i); } });
  const used = new Set(); let d = '';
  for (let i = 0; i < edges.length; i++) { // chain boundary edges into continuous lines
    if (used.has(i)) continue;
    used.add(i); let [start, cur] = edges[i]; d += `M${start}L${cur}`;
    for (;;) {
      const nx = (adj.get(cur) || []).find((j) => !used.has(j));
      if (nx == null) break;
      used.add(nx); cur = edges[nx][0] === cur ? edges[nx][1] : edges[nx][0]; d += `L${cur}`;
      if (cur === start) { d += 'Z'; break; }
    }
  }
  return d;
}
const SVGNS = 'http://www.w3.org/2000/svg';

// ---- exact-cover solver (hints in round 3, self-check) ----
function solve(T, occ0, rem, all = false) {
  const occ = new Set(occ0); const keys = [...T].sort(cmpK); const out = []; let count = 0; let first = null;
  const rec = (list) => {
    const k = keys.find((x) => !occ.has(x));
    if (!k) { if (list.length) return false; count++; if (!first) first = out.slice(); return !all; }
    const [tx, ty, tq] = parseK(k); const tried = new Set();
    for (let i = 0; i < list.length; i++) {
      const pc = list[i]; if (tried.has(pc.type)) continue; tried.add(pc.type);
      for (const r of SH[pc.type].uniq) {
        for (const [qx, qy, qq] of SH[pc.type].rots[r]) {
          if (qq !== tq) continue;
          const ks = keysAt(pc.type, r, tx - qx, ty - qy);
          if (!ks.every((x) => T.has(x) && !occ.has(x))) continue;
          ks.forEach((x) => occ.add(x)); out.push({ pid: pc.pid, rot: r, x: tx - qx, y: ty - qy });
          if (rec(list.filter((_, j) => j !== i))) return true;
          out.pop(); ks.forEach((x) => occ.delete(x));
        }
      }
    }
    return false;
  };
  rec(rem);
  return all ? count : first;
}

// ---- puzzles: [type, rot, x, y] — the union of the pieces is the silhouette ----
const P = (name, emoji, sol) => ({ name, emoji, sol: sol.map(([type, rot, x, y]) => ({ type, rot, x, y })) });
const POOL = [
  [ // round 1: 3 pieces, colour-matched outlines
    P('house', '🏠', [['roof', 0, 0, 0], ['dom', 1, 0, 1], ['dom', 1, 1, 1]]),
    P('boat', '⛵', [['btri', 0, 1, 0], ['bar3', 0, 0, 2], ['tri', 1, 3, 2]]),
    P('ice cream', '🍦', [['dom', 0, 0, 0], ['dom', 0, 0, 1], ['roof', 2, 0, 2]]),
  ],
  [ // round 2: 4-5 pieces, outlines only
    P('rocket', '🚀', [['roof', 0, 1, 0], ['big', 0, 1, 1], ['dom', 0, 1, 3], ['tri', 3, 0, 3], ['tri', 0, 3, 3]]),
    P('fish', '🐟', [['roof', 1, 0, 0], ['dom', 1, 1, 0], ['dom', 1, 2, 0], ['roof', 1, 3, 0]]),
    P('tree', '🌲', [['roof', 0, 1, 0], ['tri', 3, 0, 1], ['dom', 0, 1, 1], ['tri', 0, 3, 1], ['dom', 0, 1, 2]]),
  ],
  [ // round 3: silhouette only, any exact cover is accepted
    P('crown', '👑', [['roof', 0, 0, 0], ['roof', 0, 2, 0], ['bar3', 0, 0, 1], ['sq', 0, 3, 1], ['dom', 0, 0, 2], ['dom', 0, 2, 2]]),
    P('sailboat', '⛵', [['btri', 0, 1, 0], ['btri', 0, 3, 0], ['tri', 2, 0, 2], ['dom', 0, 1, 2], ['sq', 0, 3, 2], ['tri', 1, 4, 2]]),
    P('cat', '🐱', [['tri', 0, 0, 0], ['tri', 3, 2, 0], ['bar3', 0, 0, 1], ['dom', 0, 0, 2], ['sq', 0, 2, 2], ['bar3', 0, 0, 3]]),
    P('robot', '🤖', [['sq', 0, 1, 0], ['bar3', 0, 0, 1], ['bar3', 0, 0, 2], ['sq', 0, 0, 3], ['sq', 0, 2, 3]]),
  ],
];
const TYPE_COL = { roof: COLORS.orange, dom: COLORS.sky, btri: COLORS.pink, bar3: COLORS.green, tri: COLORS.purple, big: COLORS.yellow, sq: COLORS.green };
const PALETTE = [COLORS.red, COLORS.yellow, COLORS.green, COLORS.sky, COLORS.purple, COLORS.orange, COLORS.pink];
const NAMES = { sq: 'square', dom: 'rectangle', bar3: 'long rectangle', big: 'big square', tri: 'small triangle', btri: 'big triangle', roof: 'pointy triangle' };
const WORDS = ['One', 'Two', 'Three', 'Four', 'Five', 'Six'];
const FIT = ['It fits!', 'Snap!', 'Yes, just right!', 'Good fit!', 'Lovely!'];
const WIN = ['Wonderful!', 'Perfect fit!', 'Hooray!', 'You did it!'];

function checkPuzzles() { // self-test: no overlaps, solvable, number of solutions
  return POOL.flat().map((pz) => {
    const all = pz.sol.flatMap((s) => keysAt(s.type, s.rot, s.x, s.y));
    const T = new Set(all);
    const rem = pz.sol.map((s, i) => ({ pid: i, type: s.type }));
    return { name: pz.name, overlap: all.length !== T.size, solutions: solve(T, [], rem, true) };
  });
}
export const __test = { checkPuzzles, solve, keysAt, SH, POOL, fillD, outlineD };

export default {
  id: ID,
  parentNote: 'She fits flat shapes into an outline, turning them until they match: this is early geometry — shapes combine into new shapes, and a turned triangle is still the same triangle. Ask "Which shape could fill this corner? What if you turn it?" Many children try pieces at random or believe a turned piece no longer fits; nudge her to look at the pointy corners first.',
  async start(api) {
    let alive = true; let round = 0; let st = null; let cell = 48; let drag = null;
    let demoRunning = false; let locked = false; let wrongs = 0; let resizeT = 0;
    const PAD = 0.5, M = 8; // board margin (cells), piece hit margin (px)
    const lastPuz = [];
    api.css(`
.a-${ID}{width:100%;max-width:100%;display:flex;flex-direction:column;align-items:center;gap:8px}
.a-${ID} .hintb{min-height:56px;min-width:56px;font-size:1.05rem;align-self:center}
.a-${ID} .reveal{position:absolute;right:-14px;top:-22px;line-height:1;font-size:2.4rem;font-weight:900;display:flex;align-items:center;gap:4px;opacity:0;transition:opacity .3s;background:#fff;border:3px solid ${COLORS.green};border-radius:999px;padding:4px 12px;pointer-events:none;z-index:45}
.a-${ID} .reveal span{font-size:1.1rem}
.a-${ID} .reveal.on{opacity:1;animation:hop .6s}
.a-${ID} .play{position:relative;margin-top:16px;display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:14px;width:100%;max-width:100%}
.a-${ID} .board{position:relative;background:#fff;border:3px solid ${COLORS.ink};border-radius:20px;padding:6px;line-height:0;box-shadow:0 5px 0 rgba(43,45,66,.12)}
.a-${ID} .board svg{display:block;max-width:none}
.a-${ID} .board.won{border-color:${COLORS.green};box-shadow:0 0 0 5px rgba(6,214,160,.35)}
.a-${ID} .tray{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;align-content:center;padding:8px;border-radius:20px;background:#fff1cc;border:3px dashed #e3cf9a}
.a-${ID} .slot{flex:none}
.a-${ID} .pc{position:absolute;left:0;top:0;z-index:5;touch-action:none;user-select:none;pointer-events:none;-webkit-user-select:none}
.a-${ID} .pc svg{display:block;overflow:visible;position:absolute;left:${M}px;top:${M}px}
.a-${ID} .pc .body,.a-${ID} .pc .hit{pointer-events:all;cursor:grab}
.a-${ID} .pc.on{z-index:4}.a-${ID} .pc.on .hit{pointer-events:none}
.a-${ID} .pc.lift{z-index:40}.a-${ID} .pc.lift svg{filter:drop-shadow(0 8px 6px rgba(0,0,0,.25))}
.a-${ID} .pc.glowing svg{animation:bfpglow 1s ease-in-out infinite alternate}
@keyframes bfpglow{from{filter:drop-shadow(0 0 2px #ffb703)}to{filter:drop-shadow(0 0 9px #ffb703) drop-shadow(0 0 4px #ffd166)}}
.a-${ID} .ghost{animation:bfpblink 1.1s ease-in-out infinite alternate}
@keyframes bfpblink{from{opacity:.35}to{opacity:1}}
`);
    const wrap = h('div', { class: `a-${ID}` }); api.root.append(wrap);
    const timers = new Set();
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (alive) fn(); }, ms); timers.add(t); };

    function newRound(i) {
      round = i; locked = false; wrongs = 0; api.stage(i, 3);
      const pool = POOL[i].filter((p) => p !== lastPuz[i]);
      const puz = pick(pool); lastPuz[i] = puz;
      const T = new Set(puz.sol.flatMap((s) => keysAt(s.type, s.rot, s.x, s.y)));
      const cols = Math.max(...[...T].map((k) => parseK(k)[0])) + 1;
      const rows = Math.max(...[...T].map((k) => parseK(k)[1])) + 1;
      const cols2 = shuffle(PALETTE);
      const pieces = puz.sol.map((s, k) => {
        const startRot = i === 0 ? s.rot : rand(4);
        return { id: k, type: s.type, color: i === 0 ? TYPE_COL[s.type] : cols2[k % cols2.length], rot: startRot, startRot, placed: null, keys: null };
      });
      const slots = puz.sol.map((s, k) => ({ ...s, id: k, sig: keysAt(s.type, s.rot, s.x, s.y).sort().join(';'), by: null }));
      st = { puz, T, cols, rows, pieces, order: shuffle(pieces.map((p) => p.id)), slots, occ: new Map(), stack: [], ghost: null };
      build();
      const n = puz.name;
      api.prompt([`Put each shape on its colour. Build the ${n}!`, `Build the ${n}. Tap a shape to turn it.`, `Fill the whole ${n}. Many ways can work!`][i]);
    }

    // ---------- DOM ----------
    let play, boardBox, boardSvg, tray, reveal, hintBtn;
    function build() {
      wrap.replaceChildren();
      hintBtn = h('button', { class: 'btn hintb', 'aria-label': 'Show me a hint', onclick: () => { if (!locked && !demoRunning) { sfx('tap'); hint(false); } } }, '💡 Hint');
      reveal = h('div', { class: 'reveal', 'aria-hidden': 'true' });
      boardBox = h('div', { class: 'board' }); tray = h('div', { class: 'tray', 'aria-label': 'Shapes' });
      play = h('div', { class: 'play' }, boardBox, tray);
      boardBox.append(reveal);
      wrap.append(play);
      for (const p of st.pieces) {
        p.el = h('div', { class: 'pc', role: 'button', 'aria-label': `${NAMES[p.type]}, drag it or tap to turn` });
        p.slotEl = h('div', { class: 'slot' });
        bindPiece(p);
        play.append(p.el);
      }
      for (const id of st.order) tray.append(st.pieces[id].slotEl);
      tray.append(hintBtn);
      layout();
    }
    function layout() {
      if (!st || !alive) return;
      const H = (api.root.clientHeight || innerHeight * 0.7) - 26;
      st.pieces.forEach((p) => { p.el.style.display = 'none'; });
      let c = 64;
      for (; c > 30; c -= 2) {
        cell = c; sizeAll();
        if (play.scrollWidth <= play.clientWidth + 1 && wrap.offsetHeight <= H) break;
      }
      if (c <= 30) { cell = 30; sizeAll(); }
      st.pieces.forEach((p) => { p.el.style.display = ''; renderPiece(p); posPiece(p, false); });
    }
    function sizeAll() {
      drawBoard();
      const trayW = Math.max(...st.pieces.map((p) => Math.max(SH[p.type].max, 1.5))) * cell + 16;
      for (const p of st.pieces) {
        const s = Math.max(SH[p.type].max, 1.5) * cell + 8;
        p.slotEl.style.width = s + 'px'; p.slotEl.style.height = s + 'px';
      }
      const bw = (st.cols + 2 * PAD) * cell + 18;
      const avail = (api.root.clientWidth || innerWidth) - 26;
      const side = avail - bw - 14; // room for the tray next to the board
      tray.style.maxWidth = (side >= 2 * (trayW + 8) + 22 ? side : avail) + 'px';
    }
    function drawBoard() {
      const { T, cols, rows } = st;
      const vw = cols + 2 * PAD, vh = rows + 2 * PAD;
      const svg = document.createElementNS(SVGNS, 'svg');
      svg.setAttribute('viewBox', `${-PAD} ${-PAD} ${vw} ${vh}`);
      svg.setAttribute('width', vw * cell); svg.setAttribute('height', vh * cell);
      svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', `Outline of a ${st.puz.name}`);
      let html = '';
      for (let y = 0; y <= rows; y++) for (let x = 0; x <= cols; x++) html += `<circle cx="${x}" cy="${y}" r="0.04" fill="#cfc6b0"/>`;
      const tk = [...T];
      if (round > 0) html += `<path d="${fillD(tk)}" fill="#e4def3"/>`;
      if (round < 2) {
        for (const s of st.slots) {
          const ks = keysAt(s.type, s.rot, s.x, s.y);
          const col = round === 0 ? TYPE_COL[s.type] : COLORS.ink;
          if (round === 0) html += `<path d="${fillD(ks)}" fill="${col}" fill-opacity="0.4"/>`;
          html += `<path d="${outlineD(ks)}" fill="none" stroke="${col}" stroke-width="${round === 0 ? 3 : 2}" stroke-dasharray="7 5" stroke-linecap="round" vector-effect="non-scaling-stroke" opacity="${round === 0 ? 1 : 0.55}"/>`;
        }
      }
      html += `<path d="${outlineD(tk)}" fill="none" stroke="${COLORS.ink}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>`;
      if (st.ghost) {
        const g = st.ghost; const ks = keysAt(st.pieces[g.pid].type, g.rot, g.x, g.y);
        html += `<g class="ghost"><path d="${fillD(ks)}" fill="${st.pieces[g.pid].color}" fill-opacity="0.7"/><path d="${outlineD(ks)}" fill="none" stroke="${COLORS.ink}" stroke-width="3" stroke-dasharray="5 4" vector-effect="non-scaling-stroke"/></g>`;
      }
      svg.innerHTML = html;
      boardSvg?.remove(); boardSvg = svg; boardBox.prepend(svg);
    }
    function renderPiece(p) {
      const { w, h: hh } = SH[p.type].dims[p.rot];
      const ks = keysAt(p.type, p.rot, 0, 0);
      p.el.style.width = (w * cell + 2 * M) + 'px'; p.el.style.height = (hh * cell + 2 * M) + 'px';
      p.el.innerHTML = `<svg viewBox="0 0 ${w} ${hh}" width="${w * cell}" height="${hh * cell}" aria-hidden="true">`
        + `<rect class="hit" x="${-M / cell}" y="${-M / cell}" width="${w + 2 * M / cell}" height="${hh + 2 * M / cell}" fill="transparent"/>`
        + `<path class="body" d="${fillD(ks)}" fill="${p.color}"/>`
        + `<path d="${outlineD(ks)}" fill="none" stroke="${COLORS.ink}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke" pointer-events="none"/></svg>`;
    }
    function origin() { // board cell (0,0) top-left, in play coordinates
      const pr = play.getBoundingClientRect(), br = boardSvg.getBoundingClientRect();
      return { x: br.left - pr.left + PAD * cell, y: br.top - pr.top + PAD * cell };
    }
    function homeXY(p) {
      const pr = play.getBoundingClientRect(), sr = p.slotEl.getBoundingClientRect();
      const { w, h: hh } = SH[p.type].dims[p.rot];
      return { x: sr.left - pr.left + (sr.width - w * cell) / 2 - M, y: sr.top - pr.top + (sr.height - hh * cell) / 2 - M };
    }
    function boardXY(x, y) { const o = origin(); return { x: o.x + x * cell - M, y: o.y + y * cell - M }; }
    function posPiece(p, animate, ms = 280) {
      const t = p.placed ? boardXY(p.placed.x, p.placed.y) : homeXY(p);
      p.el.style.transition = animate ? `left ${ms}ms cubic-bezier(.3,1.25,.5,1), top ${ms}ms cubic-bezier(.3,1.25,.5,1)` : 'none';
      p.el.style.transform = '';
      p.el.style.left = t.x + 'px'; p.el.style.top = t.y + 'px';
      p.x = t.x; p.y = t.y;
      p.el.classList.toggle('on', !!p.placed);
    }

    // ---------- model ----------
    function unplace(p) {
      if (!p.placed) return;
      (p.keys || []).forEach((k) => st.occ.delete(k));
      const s = st.slots.find((x) => x.by === p.id); if (s) s.by = null;
      p.placed = null; p.keys = null; st.stack = st.stack.filter((id) => id !== p.id);
    }
    function test(p, x, y) {
      const ks = keysAt(p.type, p.rot, x, y);
      if (!ks.every((k) => st.T.has(k))) return { why: 'out' };
      if (ks.some((k) => st.occ.has(k))) return { why: 'overlap' };
      if (round < 2) {
        const sig = ks.slice().sort().join(';');
        const s = st.slots.find((q) => q.by == null && q.type === p.type && q.sig === sig);
        if (!s) return { why: 'slot' };
        return { ok: true, ks, slot: s };
      }
      return { ok: true, ks };
    }
    function commit(p, x, y, r) {
      p.placed = { x, y }; p.keys = r.ks; r.ks.forEach((k) => st.occ.set(k, p.id));
      if (r.slot) r.slot.by = p.id;
      st.stack.push(p.id);
    }
    const full = () => st.occ.size === st.T.size;

    // ---------- pointer handling ----------
    function bindPiece(p) {
      p.el.addEventListener('pointerdown', (e) => {
        if (locked || demoRunning || drag || (e.button != null && e.button > 0)) return;
        e.preventDefault();
        drag = { p, id: e.pointerId, sx: e.clientX, sy: e.clientY, dx: 0, dy: 0, moved: false };
        p.el.classList.add('lift'); p.el.style.transition = 'none';
        window.addEventListener('pointermove', onMove); window.addEventListener('pointerup', onUp); window.addEventListener('pointercancel', onUp);
      });
    }
    function stopListening() {
      window.removeEventListener('pointermove', onMove); window.removeEventListener('pointerup', onUp); window.removeEventListener('pointercancel', onUp);
    }
    function onMove(e) {
      if (!drag || e.pointerId !== drag.id) return;
      drag.dx = e.clientX - drag.sx; drag.dy = e.clientY - drag.sy;
      if (Math.abs(drag.dx) + Math.abs(drag.dy) > 7) drag.moved = true;
      if (drag.moved) drag.p.el.style.transform = `translate(${drag.dx}px, ${drag.dy}px) scale(1.05)`;
    }
    function onUp(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const d = drag; drag = null; stopListening();
      d.p.el.classList.remove('lift');
      if (!alive || demoRunning || locked) { posPiece(d.p, true); return; }
      if (!d.moved || e.type === 'pointercancel') { d.p.el.style.transform = ''; if (!d.moved) turn(d.p); else posPiece(d.p, true); return; }
      drop(d.p, d.dx, d.dy);
    }
    function turn(p) {
      sfx('flip');
      const old = SH[p.type].dims[p.rot];
      const wasPlaced = p.placed; unplace(p);
      p.rot = (p.rot + 1) % 4;
      const nw = SH[p.type].dims[p.rot];
      renderPiece(p);
      if (wasPlaced) {
        const nx = wasPlaced.x + Math.round((old.w - nw.w) / 2), ny = wasPlaced.y + Math.round((old.h - nw.h) / 2);
        const r = test(p, nx, ny);
        if (r.ok) { commit(p, nx, ny, r); posPiece(p, false); clearGhost(p); if (full()) win(); return; }
      }
      posPiece(p, false);
      if (st.ghost && st.ghost.pid === p.id && sameRot(p.type, st.ghost.rot, p.rot)) sfx('tick');
    }
    function drop(p, dx, dy) {
      const vx = p.x + dx, vy = p.y + dy; // visual top-left of the piece box
      p.el.style.transition = 'none'; p.el.style.transform = ''; p.el.style.left = vx + 'px'; p.el.style.top = vy + 'px';
      void p.el.offsetWidth;
      const o = origin(); const { w, h: hh } = SH[p.type].dims[p.rot];
      const gx = (vx + M - o.x) / cell, gy = (vy + M - o.y) / cell;
      const cx = gx + w / 2, cy = gy + hh / 2;
      const over = cx > -PAD - 0.3 && cx < st.cols + PAD + 0.3 && cy > -PAD - 0.3 && cy < st.rows + PAD + 0.3;
      const wasPlaced = !!p.placed; unplace(p);
      if (!over) { sfx('tap'); posPiece(p, true); return; }
      const cands = [];
      for (const x of new Set([Math.floor(gx), Math.ceil(gx)])) for (const y of new Set([Math.floor(gy), Math.ceil(gy)])) {
        const dist = Math.hypot(x - gx, y - gy); if (dist <= 0.9) cands.push({ x, y, dist });
      }
      cands.sort((a, b) => a.dist - b.dist);
      let firstWhy = 'out';
      for (const [n, c] of cands.entries()) {
        const r = test(p, c.x, c.y);
        if (r.ok) { commit(p, c.x, c.y, r); posPiece(p, true, 180); placedOk(p); return; }
        if (n === 0) firstWhy = r.why;
      }
      posPiece(p, true, 380);
      later(() => { p.el.classList.remove('shake'); void p.el.offsetWidth; p.el.classList.add('shake'); }, 380);
      later(() => p.el.classList.remove('shake'), 800);
      if (wasPlaced && firstWhy === 'out') { sfx('tap'); return; } // just lifting it off
      wrongs++;
      if (wrongs >= 2) { wrongs = 0; api.nudge('Look! The blinking shape shows where it fits.'); hint(true); return; }
      api.nudge({
        out: 'Oops, that pokes outside. Try turning it.',
        overlap: 'Another shape is already there. Try a new spot.',
        slot: round === 0 ? 'Find the spot with the same colour and shape.' : 'Look for an outline just like this shape.',
      }[firstWhy]);
    }
    function placedOk(p) {
      sfx('drop'); wrongs = 0; clearGhost(p);
      if (full()) { win(); return; }
      api.cheer(pick(FIT));
    }
    function clearGhost() {
      st.pieces.forEach((q) => q.el.classList.remove('glowing'));
      if (st.ghost) { st.ghost = null; drawBoard(); }
    }

    // ---------- hints ----------
    function findHint() {
      const loose = st.pieces.filter((p) => !p.placed);
      if (!loose.length) return null;
      if (round < 2) {
        for (const p of shuffle(loose)) {
          const s = st.slots.find((q) => q.by == null && q.type === p.type);
          if (s) return { pid: p.id, rot: s.rot, x: s.x, y: s.y };
        }
        return null;
      }
      const sol = solve(st.T, [...st.occ.keys()], loose.map((p) => ({ pid: p.id, type: p.type })));
      return sol ? sol[0] : false;
    }
    function hint(strong) {
      let g = findHint(); const stuck = g === false;
      if (stuck) { // round 3 dead end: lift pieces off until it can be finished again
        while (g === false && st.stack.length) {
          const p = st.pieces[st.stack[st.stack.length - 1]]; unplace(p); posPiece(p, true, 400);
          g = findHint();
        }
        api.nudge('Let us move that one back. Now try again!');
      }
      if (!g) return;
      st.ghost = g; drawBoard();
      const p = st.pieces[g.pid];
      st.pieces.forEach((q) => q.el.classList.toggle('glowing', q === p));
      if (strong && !sameRot(p.type, p.rot, g.rot)) { p.rot = g.rot; renderPiece(p); posPiece(p, false); sfx('flip'); }
      if (!strong && !stuck) api.prompt(sameRot(p.type, p.rot, g.rot) ? 'This glowing shape fits in the blinking spot.' : 'This glowing shape fits there. Tap to turn it.');
    }

    // ---------- round end ----------
    async function win() {
      if (locked) return; locked = true; clearGhost();
      const r = round;
      boardBox.classList.add('won');
      reveal.replaceChildren(st.puz.emoji, h('span', {}, st.puz.name)); reveal.classList.add('on');
      st.pieces.forEach((p, k) => later(() => { p.el.classList.add('hop'); }, k * 90));
      api.cheer(`${pick(WIN)} You built the ${st.puz.name}!`);
      await sleep(2600);
      if (!alive || r !== round) return;
      if (r < 2) newRound(r + 1); else api.finish();
    }

    // ---------- demo ----------
    api.setDemo(async () => {
      if (locked || !st || demoRunning) return;
      demoRunning = true;
      if (drag) { const d = drag; drag = null; stopListening(); d.p.el.classList.remove('lift'); }
      const me = st;
      clearGhost();
      me.pieces.forEach((p) => { unplace(p); posPiece(p, true); });
      api.prompt('Watch me fit the shapes, one by one.');
      await sleep(900); if (!alive || st !== me) return;
      let n = 0;
      for (const id of me.order) {
        const p = me.pieces[id]; const s = me.puz.sol[id];
        p.el.classList.add('glowing');
        await sleep(350); if (!alive || st !== me) return;
        while (!sameRot(p.type, p.rot, s.rot)) {
          p.rot = (p.rot + 1) % 4; renderPiece(p); posPiece(p, false); sfx('flip');
          await sleep(420); if (!alive || st !== me) return;
        }
        const r = test(p, s.x, s.y);
        if (r.ok) commit(p, s.x, s.y, r); else p.placed = { x: s.x, y: s.y };
        p.el.style.zIndex = 30; posPiece(p, true, 650); sfx('whoosh');
        api.say(WORDS[n++] || '');
        await sleep(700); if (!alive || st !== me) return;
        p.el.style.zIndex = ''; p.el.classList.remove('glowing'); sfx('drop');
        await sleep(350); if (!alive || st !== me) return;
      }
      api.cheer('All filled, no gaps! Now you try.');
      await sleep(2200); if (!alive || st !== me) return;
      me.pieces.forEach((p) => { unplace(p); p.placed = null; p.rot = p.startRot; renderPiece(p); posPiece(p, true, 450); });
      await sleep(500); if (!alive || st !== me) return;
      demoRunning = false;
      api.prompt(round === 0 ? 'Your turn! Put each shape on its colour.' : 'Your turn! Tap a shape to turn it.');
    });

    let lastSize = '';
    const onResize = () => {
      clearTimeout(resizeT);
      resizeT = setTimeout(() => {
        const sz = `${api.root.clientWidth}x${api.root.clientHeight}`;
        if (alive && !drag && !demoRunning && sz !== lastSize) { lastSize = sz; layout(); }
      }, 120);
    };
    window.addEventListener('resize', onResize);
    const ro = typeof ResizeObserver === 'function' ? new ResizeObserver(onResize) : null;
    ro?.observe(api.root);
    wrap.__bfp = { // test hook: lets an automated check read the current state
      get st() { return st; }, get cell() { return cell; }, origin: () => origin(), findHint: () => findHint(), M, same: (pid, r) => sameRot(st.pieces[pid].type, st.pieces[pid].rot, r),
    };
    newRound(0);
    return {
      destroy() {
        alive = false; stopListening(); drag = null;
        timers.forEach((t) => clearTimeout(t)); timers.clear(); clearTimeout(resizeT);
        window.removeEventListener('resize', onResize); ro?.disconnect();
      },
    };
  },
};
