// Squares That Grow — odd numbers build squares: 1, +3 = 4, +5 = 9, +7 = 16, +9 = 25.
// Each new square is the old one plus an L-shaped border (down the right side, along the bottom, AND the corner).
// Layer k (1-based) is the L of 2k-1 tiles; its cells all have max(row, col) = k-1.
import { h, sleep, shuffle, rand, pick, drag, flyTo, sfx } from '../core.js';

const CANCEL = Symbol('cancel');
const LAYER = ['#ffd166', '#ff8fab', '#4cc9f0', '#06d6a0', '#b794f4'];
const PRAISE = ['Yes!', 'Lovely!', 'Great job!', 'Super!', 'Well done!'];

// Cells of the L-layer k: right column top to bottom, then bottom row left to right (the corner is last).
const cellsOf = (k) => {
  const a = [];
  for (let r = 0; r < k - 1; r++) a.push([r, k - 1]);
  for (let c = 0; c < k; c++) a.push([k - 1, c]);
  return a;
};

const CSS = `
.a-squares-grow{--c:min(var(--cap,66px),calc((100vw - 50px)/var(--n,3) - 3px));width:100%;max-width:760px;display:flex;flex-direction:column;align-items:center;gap:10px;padding-bottom:10px;box-sizing:border-box}
.a-squares-grow *{box-sizing:border-box}
.a-squares-grow .hud{display:flex;align-items:center;justify-content:center;gap:10px 16px;flex-wrap:wrap}
.a-squares-grow .badge{display:flex;align-items:baseline;gap:8px;background:#fff;border:3px solid var(--ink);border-radius:20px;padding:2px 16px;box-shadow:0 4px 0 rgba(43,45,66,.15)}
.a-squares-grow .badge .lbl{font-weight:800}
.a-squares-grow .badge b{font-size:2.2rem;line-height:1.15;min-width:2ch;text-align:center}
.a-squares-grow .eq{font-weight:900;font-size:clamp(1.05rem,4.2vw,1.6rem);display:flex;flex-wrap:wrap;gap:4px;align-items:center;justify-content:center;min-height:1.7em}
.a-squares-grow .part{display:inline-block;min-width:1.7em;padding:0 .4em;border-radius:10px;border:2px solid rgba(43,45,66,.45);text-align:center}
.a-squares-grow .board{display:grid;grid-template-columns:repeat(var(--n),var(--c));grid-auto-rows:var(--c);gap:3px;padding:6px;background:#fff;border:3px solid var(--ink);border-radius:20px;box-shadow:0 5px 0 rgba(43,45,66,.14);max-width:100%}
.a-squares-grow .sq,.a-squares-grow .ttile{border-radius:12px;background:var(--col);border:2px solid rgba(43,45,66,.38);box-shadow:inset 0 -5px 0 rgba(43,45,66,.16),inset 0 3px 0 rgba(255,255,255,.4);display:grid;place-items:center;font-weight:900;font-size:calc(var(--c)*.4);color:rgba(43,45,66,.8);position:relative;transition:transform .2s;min-height:0;margin:0;padding:0}
.a-squares-grow .sq.pop{animation:sg-pop .38s cubic-bezier(.3,1.6,.5,1)}
.a-squares-grow .sq.rowhi{transform:translateY(-4px) scale(1.1);z-index:2}
.a-squares-grow .ghost{border:3px dashed color-mix(in srgb,var(--col) 65%,#2b2d42);border-radius:12px;background:color-mix(in srgb,var(--col) 16%,#fff);display:grid;place-items:center;font:inherit;font-weight:900;font-size:calc(var(--c)*.4);color:var(--ink);padding:0;animation:sg-pulse 1.8s ease-in-out infinite}
.a-squares-grow button.ghost{cursor:pointer}
.a-squares-grow .ghost.counted{background:var(--col);border-style:solid;animation:none}
.a-squares-grow .glow{animation:sg-glow 1s ease-in-out infinite}
.a-squares-grow .caption{min-height:1.5em;font-weight:900;font-size:1.15rem;text-align:center}
.a-squares-grow .zone{display:flex;flex-direction:column;align-items:center;gap:8px;width:100%;min-height:100px}
.a-squares-grow .cap{font-weight:800;opacity:.75}
.a-squares-grow .tray{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;padding:10px 14px;border:3px dashed #c9c3b2;border-radius:22px;background:rgba(255,255,255,.6);max-width:100%}
.a-squares-grow .ttile{width:max(56px,var(--c));height:max(56px,var(--c));cursor:grab;touch-action:none;padding:0;font:inherit}
.a-squares-grow .ttile:focus-visible,.a-squares-grow .chip:focus-visible{outline:4px solid var(--ink);outline-offset:2px}
.a-squares-grow .chip.tried{opacity:.45}
.a-squares-grow .chip.ok{background:var(--green)}
@keyframes sg-pop{from{transform:scale(.4);opacity:.3}}
@keyframes sg-pulse{50%{transform:scale(.94)}}
@keyframes sg-glow{50%{box-shadow:0 0 0 9px rgba(255,209,102,.95)}}
`;

export default {
  id: 'squares-grow',
  parentNote: 'Every square number is the one before plus an L-shaped border: 1, then +3 makes 4, +5 makes 9, +7 makes 16. Ask "how many tiles does the next L need?" and let her count the dashed squares herself. The common slip is adding a strip along each side and forgetting the corner tile, so the L comes out one short; if that happens, point at the empty corner.',

  async start(api) {
    let alive = true;
    api.css(CSS);
    const say = api.say;
    const wrap = h('div', { class: 'a-squares-grow' });
    api.root.append(wrap);

    // ---- run control: every round runs inside a "run"; starting a new run cancels the old one ----
    let run = null; let roundIdx = 0; let B = null;
    const newRun = () => { if (run) run.dead = true; run = { dead: false }; return run; };
    const live = (R) => alive && !R.dead;
    const wait = async (R, ms) => { await sleep(ms); if (!live(R)) throw CANCEL; };
    const until = async (R, p) => { const v = await p; if (!live(R)) throw CANCEL; return v; };
    const bg = (p) => p.catch((e) => { if (e !== CANCEL) console.error(e); });

    // ---- board ----
    const part = (n, l) => h('span', { class: 'part', style: { background: LAYER[l - 1] } }, String(n));
    function setHud() {
      B.badge.textContent = B.total;
      const items = B.parts.map((n, i) => part(n, i + 1));
      if (B.placed > 0 && B.placed < B.need) items.push(part(B.placed, B.k));
      const kids = [];
      items.forEach((it, i) => { if (i) kids.push(' + '); kids.push(it); });
      if (items.length > 1) kids.push(' = ' + B.total);
      B.eq.replaceChildren(...kids);
    }
    function place(el, r, c, layer) {
      el.style.gridRow = r + 1; el.style.gridColumn = c + 1; el.dataset.r = r;
      el.style.setProperty('--col', LAYER[layer - 1]);
    }
    function newBoard(N, capPx, size) {
      const badge = h('b', {}, '1'); const eq = h('div', { class: 'eq' });
      const board = h('div', { class: 'board' }); const caption = h('div', { class: 'caption' }); const zone = h('div', { class: 'zone' });
      wrap.replaceChildren(
        h('div', { class: 'hud' }, h('div', { class: 'badge', 'aria-live': 'polite' }, h('span', { class: 'lbl' }, 'Tiles'), badge), eq),
        board, caption, zone);
      wrap.style.setProperty('--n', N); wrap.style.setProperty('--cap', capPx + 'px');
      B = { N, board, badge, eq, caption, zone, ghosts: [], parts: [], total: size * size, placed: 0, need: 0, k: size,
        counting: false, cnt: 0, lock: false, misses: 0, answered: false, chips: null, full: null, resolve: null };
      for (let k = 1; k <= size; k++) {
        for (const [r, c] of cellsOf(k)) { const t = h('div', { class: 'sq' }); place(t, r, c, k); board.append(t); }
        B.parts.push(2 * k - 1);
      }
      setHud();
    }
    function showGhosts(R, k, counting) {
      B.board.querySelectorAll('.sq').forEach((t) => { t.textContent = ''; });
      B.ghosts = cellsOf(k).map(([r, c]) => {
        const g = h(counting ? 'button' : 'div', { class: 'ghost', type: counting ? 'button' : null, 'aria-label': counting ? 'dashed square, tap to count' : null });
        place(g, r, c, k);
        if (counting) g.addEventListener('click', () => countGhost(R, g));
        B.board.append(g); return g;
      });
      Object.assign(B, { k, need: 2 * k - 1, placed: 0, cnt: 0, counting, misses: 0 });
      B.full = new Promise((res) => { B.resolve = res; });
      setHud();
    }
    function countGhost(R, g, force) {
      if (!live(R) || !B.counting || (B.lock && !force) || !g.classList.contains('ghost') || g.dataset.cnt) return;
      B.cnt++; g.dataset.cnt = B.cnt; g.textContent = B.cnt; g.classList.add('counted');
      sfx('tick'); say(String(B.cnt));
    }
    async function autoCount(R, delay = 0) {
      B.lock = true;
      if (delay) await wait(R, delay);
      for (const g of B.ghosts) {
        if (g.dataset.cnt || !g.classList.contains('ghost')) continue;
        await wait(R, 420); countGhost(R, g, true);
      }
      await wait(R, 300); B.lock = false;
    }
    function fillGhost(g) {
      g.className = 'sq pop'; g.removeAttribute('role'); delete g.dataset.cnt; delete g.dataset.claim;
      B.placed++; B.total++; g.textContent = B.total;
      if (B.placed === B.need) B.parts.push(B.need);
      setHud(); sfx('pop'); say(String(B.total));
      if (B.placed === B.need) B.resolve();
    }
    async function autoFill(R) {
      for (const g of B.ghosts) {
        if (!g.classList.contains('ghost')) continue;
        await wait(R, 340); fillGhost(g);
      }
    }
    async function sweep(R, m) {
      for (let r = 0; r < m; r++) {
        B.board.querySelectorAll('.sq').forEach((t) => t.classList.toggle('rowhi', +t.dataset.r === r));
        B.caption.textContent = `${r + 1} row${r ? 's' : ''} of ${m}`;
        sfx('tick'); await wait(R, 380);
      }
      B.board.querySelectorAll('.sq').forEach((t) => t.classList.remove('rowhi'));
      B.caption.textContent = `${m} rows of ${m} = ${m * m}`;
      await wait(R, 900);
    }

    // ---- tray (tiles to drag) ----
    const unclaimed = () => B.ghosts.filter((g) => g.classList.contains('ghost') && !g.dataset.claim);
    const nextGhost = () => unclaimed()[0] || null;
    function nearGhost(el) {
      const a = el.getBoundingClientRect(); const ax = a.left + a.width / 2; const ay = a.top + a.height / 2;
      let best = null; let bd = 1e9;
      for (const g of unclaimed()) {
        const b = g.getBoundingClientRect();
        const d = Math.hypot(ax - (b.left + b.width / 2), ay - (b.top + b.height / 2));
        if (d < bd) { bd = d; best = g; }
      }
      return bd < Math.max(84, (best ? best.getBoundingClientRect().width : 0) * 1.5) ? best : null;
    }
    async function send(R, tile, g, fly) {
      g.dataset.claim = '1'; B.misses = 0;
      B.ghosts.forEach((x) => x.classList.remove('glow'));
      if (fly) { tile.style.zIndex = 5; await flyTo(tile, g, { duration: 400 }); if (!live(R)) return; }
      tile.remove(); fillGhost(g);
    }
    function miss(R) {
      B.misses++;
      api.nudge(pick(['Drop it on a dashed square.', 'Put it in the dashed L.']));
      if (B.misses >= 2) unclaimed().forEach((g) => g.classList.add('glow'));
    }
    function makeTray(R, k) {
      const n = 2 * k - 1;
      const tiles = Array.from({ length: n }, () => {
        const t = h('button', { class: 'ttile', type: 'button', 'aria-label': 'tile, tap to place' });
        t.style.setProperty('--col', LAYER[k - 1]);
        drag(t, { onDrop: (_x, el, moved) => {
          if (!live(R) || B.lock) return false;
          const g = moved ? nearGhost(el) : nextGhost();
          if (!g) { if (moved) miss(R); return false; }
          bg(send(R, el, g, !moved)); return true;
        } });
        t.addEventListener('keydown', (e) => {
          if ((e.key === 'Enter' || e.key === ' ') && live(R)) { e.preventDefault(); const g = nextGhost(); if (g) bg(send(R, t, g, true)); }
        });
        return t;
      });
      B.zone.replaceChildren(h('div', { class: 'cap' }, `${n} tiles to place`), h('div', { class: 'tray' }, tiles));
      try { B.zone.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch { /* ignore */ }
      return tiles;
    }
    async function buildLayer(R, k, demo) {
      if (!(B.k === k && B.ghosts.length && B.placed === 0)) showGhosts(R, k, false);
      B.counting = false;
      B.ghosts.forEach((g) => { g.classList.remove('counted'); g.textContent = ''; delete g.dataset.cnt; if (g.tagName === 'BUTTON') g.removeAttribute('aria-label'); });
      const tiles = makeTray(R, k);
      if (demo) {
        for (const t of tiles) { await wait(R, 160); await send(R, t, nextGhost(), true); await wait(R, 260); }
      }
      await until(R, B.full);
      B.zone.replaceChildren();
    }

    // ---- number chips ----
    function ask(R, { options, correct, hint, onStrong }) {
      return new Promise((resolve) => {
        let wrong = 0; const btns = new Map();
        const row = h('div', { class: 'act-row' });
        [...new Set(options)].forEach((v) => {
          const b = h('button', { type: 'button', class: 'chip choice', 'aria-label': `${v} tiles`, onclick: () => {
            if (!live(R) || B.lock || B.answered) return;
            sfx('tap');
            if (v === correct) { B.answered = true; b.classList.add('ok', 'hop'); btns.forEach((x) => { x.disabled = true; x.classList.remove('glow'); }); resolve(); return; }
            wrong++;
            b.classList.remove('shake'); void b.offsetWidth; b.classList.add('shake', 'tried');
            api.nudge(hint(v));
            if (wrong >= 2) { btns.get(correct).classList.add('glow'); onStrong?.(); }
          } }, String(v));
          btns.set(v, b); row.append(b);
        });
        B.answered = false; B.chips = btns;
        B.zone.replaceChildren(h('div', { class: 'cap' }, 'Tap a number'), row);
      });
    }
    async function demoPick(R, correct) {
      await wait(R, 300);
      const b = B.chips.get(correct); b.classList.add('hop'); await wait(R, 600); b.click();
    }
    const glowCorner = () => { const g = B.ghosts[B.ghosts.length - 1]; if (g) g.classList.add('glow'); };

    // ---- the three rounds ----
    async function round1(R, demo) {
      api.stage(0, 3); newBoard(3, 80, 1);
      for (let k = 2; k <= 3; k++) {
        const p = api.prompt(k === 2 ? 'Add 3 tiles to make a 2 by 2 square.' : 'Now add 5 tiles. Make a 3 by 3 square!');
        if (demo) await until(R, p);
        await buildLayer(R, k, demo);
        await until(R, api.cheer(`${pick(PRAISE)} A ${k} by ${k} square: ${k * k} tiles.`));
        await sweep(R, k);
      }
    }

    async function round2(R, demo) {
      api.stage(1, 3);
      const start = pick([2, 3]);
      newBoard(start + 2, 66, start);
      for (let q = 0; q < 2; q++) {
        const k = start + q; const m = k + 1; const n = 2 * k + 1;
        showGhosts(R, m, true);
        const p = api.prompt('Count the dashed squares. How many tiles make the next L?');
        if (demo) { await until(R, p); await autoCount(R); await wait(R, 300); }
        const answered = ask(R, {
          options: shuffle([n, 2 * k, pick([2 * k + 2, 2 * k - 1])]), correct: n,
          hint: (v) => { if (v === 2 * k) { glowCorner(); return 'So close! The corner needs a tile too.'; } return 'Tap each dashed square and count them.'; },
          onStrong: () => bg(autoCount(R, 1500)),
        });
        if (demo) await demoPick(R, n);
        await until(R, answered);
        B.ghosts.forEach((g) => g.classList.remove('glow'));
        B.zone.replaceChildren(); B.counting = false;
        await autoFill(R);
        await until(R, api.cheer(`${pick(PRAISE)} ${n} tiles. Now there are ${m * m}.`));
        if (q === 1) await sweep(R, m); else await wait(R, 700);
      }
    }

    async function round3(R, demo) {
      api.stage(2, 3); newBoard(5, 66, 2);
      const flip = rand(2);
      for (let k = 2; k <= 4; k++) {
        const m = k + 1; const n = 2 * k + 1; const total = (k + flip) % 2 === 0;
        const p = api.prompt(total ? `How many tiles will the ${m} by ${m} square have?` : 'How many tiles will the next L need?');
        const peek = () => { if (!B.ghosts.length) showGhosts(R, m, true); bg(autoCount(R, 1500)); };
        const answered = ask(R, {
          options: shuffle(total ? [m * m, m * m - 1, pick([k * k + m, m * m + 2])] : [n, 2 * k, pick([2 * k + 2, 2 * k - 1])]),
          correct: total ? m * m : n,
          hint: (v) => {
            if (v === m * m - 1 || v === 2 * k) return 'So close! Count the corner tile too.';
            return total ? `The old square has ${k * k}. Add the next L.` : 'Count down, across, and the corner.';
          },
          onStrong: peek,
        });
        if (demo) {
          await until(R, p);
          showGhosts(R, m, true); await autoCount(R);
          await until(R, say(total ? `${k * k} tiles now. The L needs ${n}. ${k * k} plus ${n} makes ${m * m}.` : `${k} down, ${k} across, and one corner. That makes ${n}.`));
          await wait(R, 500);
          await demoPick(R, total ? m * m : n);
        }
        await until(R, answered);
        api.cheer(pick(['Good thinking! Let us build it.', 'Yes! Now we build to check.']));
        await wait(R, 900);
        await buildLayer(R, m, demo);
        await until(R, api.cheer(total ? `${m * m} tiles! Your guess was right.` : `${n} tiles! ${m * m} in all.`));
        if (k === 4) await sweep(R, 5); else await wait(R, 800);
      }
    }
    const rounds = [round1, round2, round3];

    async function loop() {
      while (alive && roundIdx < 3) {
        const R = newRun();
        try { await rounds[roundIdx](R, false); } catch (e) { if (e === CANCEL) return; throw e; }
        if (R.dead) return;
        roundIdx++;
      }
      if (alive) api.finish();
    }

    api.setDemo(async () => {
      const R = newRun();
      try { await rounds[Math.min(roundIdx, 2)](R, true); } catch (e) { if (e === CANCEL) return; throw e; }
      if (live(R)) bg(loop());
    });

    bg(loop());
    return { destroy() { alive = false; if (run) run.dead = true; } };
  },
};
