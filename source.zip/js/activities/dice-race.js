import { h, sleep, shuffle, rand, flyTo, sfx } from '../core.js';

// Dice Race: animals own numbers; each roll moves the animal whose number comes up.
// Numbers that can happen in more ways (two faces on one die; 7 with two dice) usually win,
// but real Math.random rolls are used, so an upset can happen and is described honestly.

const ANIMALS = [
  ['🐰', 'bunny'], ['🐢', 'turtle'], ['🐥', 'chick'], ['🐱', 'kitten'], ['🐶', 'puppy'], ['🦊', 'fox'],
  ['🐼', 'panda'], ['🐨', 'koala'], ['🐸', 'frog'], ['🐷', 'piglet'], ['🐭', 'mouse'], ['🦔', 'hedgehog'],
];
const LANE_TINT = ['#ff8fab', '#4cc9f0', '#ffd166'];
const PIPS = {
  1: [[50, 50]], 2: [[28, 28], [72, 72]], 3: [[28, 28], [50, 50], [72, 72]],
  4: [[28, 28], [72, 28], [28, 72], [72, 72]], 5: [[28, 28], [72, 28], [50, 50], [28, 72], [72, 72]],
  6: [[28, 26], [72, 26], [28, 50], [72, 50], [28, 74], [72, 74]],
};
function dieHTML(n, color = '#fff', pip = '#2b2d42') {
  return `<rect x="5" y="5" width="90" height="90" rx="20" fill="${color}" stroke="#2b2d42" stroke-width="6"/>` +
    PIPS[n].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="9" fill="${pip}"/>`).join('');
}
function die(n, cls = 'die', color, pip) {
  const s = h('svg', { viewBox: '0 0 100 100', class: cls, 'aria-hidden': 'true' });
  s.innerHTML = dieHTML(n, color, pip); s._n = n; return s;
}
function setDie(s, n, color, pip) { s.innerHTML = dieHTML(n, color, pip); s._n = n; }

const CSS = `
.a-dice-race{width:100%;max-width:640px;display:flex;flex-direction:column;gap:10px;align-items:stretch;position:relative}
.a-dice-race .lanes{display:flex;flex-direction:column;gap:8px;background:#fff;border:3px solid var(--ink);border-radius:20px;padding:8px}
.a-dice-race .lane{display:flex;align-items:center;gap:6px}
.a-dice-race .who{flex:0 0 108px;width:108px;min-width:0;box-sizing:border-box;min-height:62px;display:flex;align-items:center;justify-content:center;gap:3px;border:3px solid var(--ink);border-radius:16px;background:#fff;font:inherit;color:inherit;cursor:pointer;padding:2px 4px;position:relative;box-shadow:0 3px 0 rgba(43,45,66,.15)}
.a-dice-race .who .ani{font-size:1.9rem;line-height:1}
.a-dice-race .who .mini{width:22px;height:22px;flex:0 0 22px}
.a-dice-race .who .num{min-width:30px;height:30px;border-radius:50%;border:3px solid var(--ink);display:grid;place-items:center;font-weight:900;font-size:1rem;background:#fff}
.a-dice-race .who.sel{background:var(--yellow)}
.a-dice-race .who .pk{position:absolute;top:-12px;right:-10px;font-size:1.2rem}
.a-dice-race .who .wins{position:absolute;bottom:-11px;left:50%;transform:translateX(-50%);font-size:.75rem;font-weight:900;background:#fff;border:2px solid var(--ink);border-radius:99px;padding:0 5px;white-space:nowrap}
.a-dice-race .track{flex:1;display:flex;gap:3px;min-width:0}
.a-dice-race .cell{flex:1;min-width:0;height:58px;border-radius:12px;background:#f4eedd;display:grid;place-items:center;font-size:clamp(1.4rem,5vw,2rem);line-height:1}
.a-dice-race .runner{display:inline-block}
.a-dice-race .cell.fin{background:repeating-conic-gradient(#d9d2c0 0 25%,#fff 0 50%) 0 0/18px 18px;border:2px dashed var(--ink)}
.a-dice-race .lane.won .cell.fin{background:#d9fbe9}
.a-dice-race .tray{display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;min-height:86px}
.a-dice-race .die{width:76px;height:76px}
.a-dice-race .die.roll{animation:dr-tumble .5s ease-out}
.a-dice-race .die.fast{animation-duration:.2s}
@keyframes dr-tumble{0%{transform:rotate(0) translateY(0)}35%{transform:rotate(140deg) translateY(-18px)}70%{transform:rotate(290deg) translateY(0)}100%{transform:rotate(360deg)}}
.a-dice-race .sum{font-size:clamp(1.3rem,5vw,1.9rem);font-weight:900;min-width:70px;text-align:center}
.a-dice-race .info{text-align:center;font-weight:800;min-height:1.5em;color:#5c5a52}
.a-dice-race .btns{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}
.a-dice-race .btns .btn{min-height:58px;font-size:1.1rem}
.a-dice-race .ways{display:flex;flex-wrap:wrap;gap:8px 16px;justify-content:center;background:#fff;border:3px dashed var(--line);border-radius:16px;padding:8px 10px;font-weight:800}
.a-dice-race .ways>span{display:inline-flex;align-items:center;gap:4px}
.a-dice-race .ways .dotw{width:14px;height:14px;border-radius:50%;background:var(--green);border:2px solid var(--ink)}
.a-dice-race .ways .mini{width:22px;height:22px}
.a-dice-race .finger{position:absolute;left:0;top:0;font-size:2.4rem;pointer-events:none;z-index:50;opacity:0;transition:opacity .2s}
.a-dice-race .finger.on{opacity:1}
.a-dice-race .grid{display:grid;grid-template-columns:minmax(28px,.7fr) repeat(6,minmax(0,1fr));gap:4px;width:100%;max-width:max(300px,min(470px,calc(100dvh - 330px)));align-self:center}
.a-dice-race .hd{display:grid;place-items:center;font-weight:900;font-size:1.4rem}
.a-dice-race .hd svg{width:88%;max-width:46px;height:auto}
.a-dice-race .gc{aspect-ratio:1;min-height:46px;border:3px solid var(--ink);border-radius:12px;background:#fff;font:inherit;font-weight:900;font-size:clamp(1rem,4.6vw,1.6rem);color:var(--ink);cursor:pointer;padding:0;transition:background .2s}
.a-dice-race .gc.seen{background:#f1ecdf;color:#8a8577}
.a-dice-race .gc.seven{background:var(--green);color:#fff}
.a-dice-race .gc.one{outline:3px dashed var(--orange);outline-offset:-6px}
.a-dice-race .count{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.a-dice-race .count .chip{font-weight:900}
`;

export default {
  id: 'dice-race',
  parentNote: 'Each animal owns a number and steps forward when its number is rolled. Ask: “Which number can happen in more ways?” With two dice, 7 can be made six ways but 2 and 12 only one way each. Children often think every number is equally likely, or that wishing helps — and a few rolls can still surprise, so race more than once and talk about “usually”, not “always”.',
  async start(api) {
    let alive = true; let epoch = 0; let busy = false; let round = 0;
    api.css(CSS);
    const wrap = h('div', { class: 'a-dice-race' }); api.root.append(wrap);
    const finger = h('div', { class: 'finger', 'aria-hidden': 'true' }, '👆');
    const ok = (e) => alive && e === epoch;

    async function pointAt(el, dur = 450) {
      if (!el) return;
      finger.classList.add('on');
      await flyTo(finger, el, { duration: dur, offset: { x: 10, y: 22 } });
    }
    const hideFinger = () => finger.classList.remove('on');
    async function waitIdle() { while (busy && alive) await sleep(60); }

    // ---------------- race rounds ----------------
    const RACES = [
      { twoDice: false, steps: 4, owners: [[1, 2], [6]] },
      { twoDice: true, steps: 4, owners: [[2], [7], [12]] },
    ];
    const waysOf = (nums, two) => {
      let c = 0;
      if (!two) return nums.length;
      for (let a = 1; a <= 6; a++) for (let b = 1; b <= 6; b++) if (nums.includes(a + b)) c++;
      return c;
    };

    function buildRace(ri) {
      const e = ++epoch; busy = false;
      const cfg = RACES[ri];
      const animals = shuffle(ANIMALS).slice(0, cfg.owners.length);
      const lanes = shuffle(cfg.owners).map((nums, i) => ({
        nums, ani: animals[i][0], name: animals[i][1], ways: waysOf(nums, cfg.twoDice), tint: LANE_TINT[i], wins: 0,
      }));
      const best = lanes.reduce((b, l, i) => (l.ways > lanes[b].ways ? i : b), 0);
      const st = { pick: null, pos: lanes.map(() => 0), rolls: 0, done: false };

      wrap.replaceChildren(finger);
      const lanesBox = h('div', { class: 'lanes' });
      lanes.forEach((l, i) => {
        const who = h('button', { class: 'who', style: { borderColor: l.tint }, 'aria-label': `${l.name}, number ${l.nums.join(' or ')}` },
          h('span', { class: 'ani' }, l.ani),
          cfg.twoDice ? h('span', { class: 'num', style: { background: l.tint } }, String(l.nums[0])) : l.nums.map((n) => die(n, 'mini')));
        who.addEventListener('click', () => choose(i));
        const cells = Array.from({ length: cfg.steps + 1 }, (_, k) => h('div', { class: 'cell' + (k === cfg.steps ? ' fin' : '') }));
        const runner = h('span', { class: 'runner' }, l.ani);
        cells[0].append(runner);
        const lane = h('div', { class: 'lane' }, who, h('div', { class: 'track' }, cells));
        Object.assign(l, { who, cells, runner, lane });
        lanesBox.append(lane);
      });
      const dice = cfg.twoDice ? [die(1 + rand(6)), die(1 + rand(6), 'die', '#fff1f4')] : [die(1 + rand(6))];
      const sum = h('div', { class: 'sum' }, '');
      const tray = h('div', { class: 'tray' }, dice, sum);
      const info = h('div', { class: 'info' }, '');
      const roll1 = h('button', { class: 'btn primary', 'aria-label': 'Roll the dice' }, cfg.twoDice ? '🎲🎲 Roll' : '🎲 Roll');
      const roll10 = h('button', { class: 'btn', 'aria-label': 'Roll ten times' }, '🎲 ×10');
      const rollRow = h('div', { class: 'btns' }, roll1, roll10);
      const waysBox = h('div', { class: 'ways', hidden: true });
      const again = h('button', { class: 'btn' }, '↻ Race again');
      const next = h('button', { class: 'btn primary' }, ri === 0 ? 'Next: two dice ➜' : 'Next: the dice table ➜');
      const afterRow = h('div', { class: 'btns', hidden: true }, again, next);
      wrap.append(lanesBox, tray, info, rollRow, waysBox, afterRow);

      // ways panel (shown after the first finished race)
      lanes.forEach((l) => {
        waysBox.append(h('span', {}, l.ani,
          cfg.twoDice ? h('b', {}, `${l.nums[0]}:`) : l.nums.map((n) => die(n, 'mini')),
          Array.from({ length: l.ways }, () => h('i', { class: 'dotw' })),
          `${l.ways} ${l.ways === 1 ? 'way' : 'ways'}`));
      });

      function choose(i) {
        if (!ok(e) || busy) return;
        if (st.done) return;
        if (st.rolls > 0) { api.nudge('The race has started. Keep rolling!'); return; }
        st.pick = i; sfx('pop');
        lanes.forEach((l, k) => {
          l.who.classList.toggle('sel', k === i);
          l.who.querySelector('.pk')?.remove();
          if (k === i) l.who.append(h('span', { class: 'pk', 'aria-hidden': 'true' }, '⭐'));
        });
        lanes[i].who.classList.add('hop'); setTimeout(() => lanes[i].who.classList.remove('hop'), 500);
        api.prompt(`You picked the ${lanes[i].name}. Now roll!`);
      }

      async function animateDice(vals, speed) {
        const ms = speed === 'slow' ? 520 : speed === 'fast' ? 220 : 150;
        dice.forEach((d) => { d.classList.remove('roll', 'fast'); void d.getBoundingClientRect(); d.classList.add('roll'); if (speed !== 'slow') d.classList.add('fast'); });
        sfx('flip');
        const t0 = performance.now();
        while (performance.now() - t0 < ms - 60) {
          dice.forEach((d, k) => setDie(d, 1 + rand(6), k ? '#fff1f4' : '#fff'));
          await sleep(70);
          if (!ok(e)) return;
        }
        dice.forEach((d, k) => setDie(d, vals[k], k ? '#fff1f4' : '#fff'));
        await sleep(60);
      }

      async function rollOnce(speed) {
        const vals = dice.map(() => 1 + rand(6));
        await animateDice(vals, speed);
        if (!ok(e)) return;
        const s = vals.reduce((a, b) => a + b, 0);
        st.rolls++;
        sum.textContent = cfg.twoDice ? `= ${s}` : '';
        const li = lanes.findIndex((l) => l.nums.includes(s));
        if (li < 0) { info.textContent = `${s}: nobody has ${s}. · Rolls: ${st.rolls}`; sfx('tick'); return; }
        const l = lanes[li];
        st.pos[li]++;
        l.cells[st.pos[li]].append(l.runner);
        l.runner.classList.remove('hop'); void l.runner.offsetWidth; l.runner.classList.add('hop');
        sfx('step');
        info.textContent = `${s}: the ${l.name} steps! · Rolls: ${st.rolls}`;
        if (st.pos[li] >= cfg.steps) await finishRace(li);
      }

      async function finishRace(li) {
        st.done = true;
        const l = lanes[li]; l.wins++;
        l.lane.classList.add('won'); l.who.classList.add('glow');
        l.who.querySelector('.wins')?.remove();
        l.who.append(h('span', { class: 'wins' }, `🏆 ${l.wins}`));
        rollRow.hidden = true; waysBox.hidden = false; afterRow.hidden = false;
        afterRow.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
        if (li === best) {
          if (st.pick === li) api.cheer(pickPhrase([`The ${l.name} won! Good thinking!`, `Yes! The ${l.name} won the race!`]));
          else api.cheer(`The ${l.name} won! More ways means more steps.`);
        } else {
          api.prompt(`The ${l.name} got lucky this time! Race again?`);
        }
      }

      async function rollMany(n, speed) {
        if (!ok(e) || busy || st.done) return;
        if (st.pick == null) { api.nudge('First tap the animal you think will win.'); lanes.forEach((l) => l.who.classList.add('shake')); setTimeout(() => lanes.forEach((l) => l.who.classList.remove('shake')), 420); return; }
        busy = true;
        for (let k = 0; k < n && ok(e) && !st.done; k++) {
          await rollOnce(speed);
          if (n > 1) await sleep(speed === 'demo' ? 40 : 120);
        }
        if (ok(e)) busy = false;
      }
      roll1.addEventListener('click', () => rollMany(1, 'slow'));
      roll10.addEventListener('click', () => rollMany(10, 'fast'));

      function resetRace() {
        st.pick = null; st.pos = lanes.map(() => 0); st.rolls = 0; st.done = false;
        lanes.forEach((l) => {
          l.runner.classList.remove('hop'); l.cells[0].append(l.runner); l.lane.classList.remove('won');
          l.who.classList.remove('sel', 'glow'); l.who.querySelector('.pk')?.remove();
        });
        sum.textContent = ''; info.textContent = ''; rollRow.hidden = false; afterRow.hidden = true;
      }
      again.addEventListener('click', () => { if (!ok(e)) return; sfx('tap'); resetRace(); api.prompt('Who will win this time? Tap an animal.'); });
      next.addEventListener('click', () => { if (!ok(e)) return; sfx('tap'); goRound(ri + 1); });

      api.setDemo(async () => {
        await waitIdle(); if (!ok(e)) return;
        resetRace(); waysBox.hidden = false;
        const b = lanes[best];
        await api.say(cfg.twoDice ? 'Seven can be made in six ways. Two and twelve, only one way.' : 'One or two is two faces. Six is just one face.');
        if (!ok(e)) return;
        await pointAt(b.who); if (!ok(e)) return;
        choose(best); await sleep(700); if (!ok(e)) return;
        await pointAt(roll10); if (!ok(e)) return;
        hideFinger();
        api.prompt(cfg.twoDice ? '7 has the most ways. Lots of quick rolls!' : 'Two faces, not one. Lots of quick rolls!');
        busy = true;
        for (let k = 0; k < 200 && ok(e) && !st.done; k++) { await rollOnce('demo'); await sleep(40); }
        if (!ok(e)) return;
        busy = false;
        await sleep(1800); if (!ok(e)) return;
        const winner = lanes.findIndex((l, i) => st.pos[i] >= cfg.steps);
        await api.say(winner === best ? 'More ways usually wins. Not always!' : 'A surprise! Lucky rolls happen sometimes.');
        if (!ok(e)) return;
        await sleep(600); if (!ok(e)) return;
        resetRace(); waysBox.hidden = true;
        api.prompt('Your turn! Who will win? Tap an animal.');
      });

      api.prompt(ri === 0 ? 'Who will win the race? Tap an animal.' : 'Two dice now! Who will win? Tap one.');
    }

    let lastPhrase = '';
    function pickPhrase(list) {
      const opts = list.filter((p) => p !== lastPhrase);
      lastPhrase = opts[rand(opts.length)]; return lastPhrase;
    }

    // ---------------- round 3: the ways table ----------------
    function buildTable() {
      const e = ++epoch; busy = false;
      const st = { found: 0, misses: 0, phase: 'find', countMiss: 0 };
      wrap.replaceChildren(finger);
      const grid = h('div', { class: 'grid' });
      const cells = [];
      grid.append(h('div', { class: 'hd', 'aria-hidden': 'true' }, '+'));
      for (let c = 1; c <= 6; c++) grid.append(h('div', { class: 'hd' }, die(c, 'hdie', '#fff1f4')));
      for (let r = 1; r <= 6; r++) {
        grid.append(h('div', { class: 'hd' }, die(r, 'hdie', '#fff')));
        for (let c = 1; c <= 6; c++) {
          const b = h('button', { class: 'gc', 'aria-label': `${r} and ${c}` }, '');
          b._r = r; b._c = c; b._s = r + c; b._open = false;
          b.addEventListener('click', () => tapCell(b));
          grid.append(b); cells.push(b);
        }
      }
      const status = h('div', { class: 'info' }, 'Found: 0');
      const countRow = h('div', { class: 'count', hidden: true });
      wrap.append(grid, status, countRow);
      const sevens = () => cells.filter((b) => b._s === 7);

      function reveal(b) {
        b._open = true; b.textContent = String(b._s);
        b.classList.add(b._s === 7 ? 'seven' : 'seen');
      }
      async function tapCell(b) {
        if (!ok(e) || busy || st.phase !== 'find') return;
        if (b._open) { api.say(`${b._r} and ${b._c} make ${b._s}.`); return; }
        reveal(b);
        if (b._s === 7) {
          st.found++; st.misses = 0; sfx('pop');
          cells.forEach((x) => x.classList.remove('glow'));
          b.classList.add('hop');
          status.textContent = `Found: ${st.found}`;
          if (st.found >= 6) { await allFound(); return; }
          api.cheer(pickPhrase([`${b._r} and ${b._c} make 7!`, 'Yes, that makes 7!', `Seven! ${b._r} and ${b._c}.`]));
        } else {
          st.misses++;
          b.classList.add('shake'); setTimeout(() => b.classList.remove('shake'), 420);
          if (st.misses >= 2) {
            const left = sevens().find((x) => !x._open);
            left?.classList.add('glow');
            api.nudge('Try the shining box. Count all the dots.');
          } else api.nudge(`${b._r} and ${b._c} make ${b._s}. Find a 7.`);
        }
      }
      async function allFound() {
        st.phase = 'wave'; busy = true;
        api.cheer('You found them all! Look at the line!');
        for (const x of cells) {
          if (!ok(e)) return;
          if (!x._open) { reveal(x); await sleep(25); }
        }
        cells.filter((x) => x._s === 2 || x._s === 12).forEach((x) => x.classList.add('one'));
        await sleep(900); if (!ok(e)) return;
        busy = false; st.phase = 'count';
        showCount();
      }
      function showCount() {
        countRow.replaceChildren();
        shuffle([4, 5, 6]).forEach((n) => {
          const c = h('button', { class: 'chip choice', 'aria-label': String(n) }, String(n));
          c._n = n;
          c.addEventListener('click', () => answer(c));
          countRow.append(c);
        });
        countRow.hidden = false;
        countRow.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
        api.prompt('How many green boxes make 7? Count them!');
      }
      async function answer(c) {
        if (!ok(e) || busy || st.phase !== 'count') return;
        if (c._n === 6) {
          st.phase = 'done'; busy = true; c.classList.add('sel', 'hop');
          await api.cheer('Six ways to make 7! Only one way for 2.');
          await sleep(1200); if (!ok(e)) return;
          busy = false; api.finish();
        } else {
          st.countMiss++;
          c.classList.add('shake'); setTimeout(() => c.classList.remove('shake'), 420);
          if (st.countMiss >= 2) {
            [...countRow.children].find((x) => x._n === 6)?.classList.add('glow');
            api.nudge('Touch each green box and count slowly.');
          } else api.nudge('Let us count the green boxes again.');
        }
      }

      api.setDemo(async () => {
        await waitIdle(); if (!ok(e)) return;
        if (st.phase === 'done') return;
        busy = true;
        cells.forEach((x) => { x._open = false; x.textContent = ''; x.className = 'gc'; });
        countRow.hidden = true; st.phase = 'demo';
        await api.say('Which boxes make seven? Add the two dice.');
        const words = ['one', 'two', 'three', 'four', 'five', 'six'];
        const list = sevens();
        for (const b of list) {
          if (!ok(e)) return;
          await pointAt(b, 380); if (!ok(e)) return;
          reveal(b); sfx('pop'); status.textContent = `Found: ${list.indexOf(b) + 1}`;
          await api.say(`${b._r} and ${b._c} make seven.`);
          await sleep(350);
        }
        if (!ok(e)) return;
        for (let i = 0; i < list.length; i++) {
          await pointAt(list[i], 260); if (!ok(e)) return;
          list[i].classList.add('hop'); setTimeout(() => list[i].classList.remove('hop'), 500);
          await api.say(words[i]); await sleep(250);
        }
        if (!ok(e)) return;
        await api.say('Six ways to make seven!'); await sleep(900);
        hideFinger(); if (!ok(e)) return;
        cells.forEach((x) => { x._open = false; x.textContent = ''; x.className = 'gc'; });
        st.found = 0; st.misses = 0; st.countMiss = 0; st.phase = 'find'; status.textContent = 'Found: 0';
        busy = false;
        api.prompt('Your turn! Tap every box that makes 7.');
      });

      api.prompt('Tap every box where the dice make 7.');
    }

    function goRound(i) {
      if (!alive) return;
      round = i; api.stage(round, 3); hideFinger();
      if (i < 2) buildRace(i); else buildTable();
    }
    goRound(0);

    return { destroy() { alive = false; epoch++; } };
  },
};
