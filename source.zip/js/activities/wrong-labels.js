import { h, sleep, shuffle, pick, drag, flyTo, sfx, settings } from '../core.js';

// ---------- pure puzzle logic (exported for brute-force tests) ----------
// Keys: 'a' = only fruit A, 'p' = only fruit P, 'm' = mixed (both).
// labels[i] = tag on box i; contents[i] = what is really inside. Every tag is wrong.
export function derangements(labels) {
  const out = [];
  const rec = (cur, rest) => {
    if (!rest.length) { if (cur.every((k, i) => k !== labels[i])) out.push(cur); return; }
    rest.forEach((k, j) => rec([...cur, k], rest.filter((_, q) => q !== j)));
  };
  rec([], labels.slice());
  return out;
}
// A peek {i, f} means "one fruit f came out of box i": box i holds only f, or is mixed.
export const consistent = (arr, peeks) => peeks.every((p) => arr[p.i] === p.f || arr[p.i] === 'm');
export const possible = (labels, peeks) => derangements(labels).filter((a) => consistent(a, peeks));
export const drawFrom = (content) => (content === 'm' ? pick(['a', 'p']) : content);
export function arrangement(n) {
  const labels = shuffle(n === 2 ? ['a', 'p'] : ['a', 'p', 'm']);
  return { labels, truth: pick(derangements(labels)) };
}

const FRUITS = [
  { a: '🍎', p: '🍐', an: 'apples', pn: 'pears', a1: 'An apple', p1: 'A pear' },
  { a: '🍊', p: '🍋', an: 'oranges', pn: 'lemons', a1: 'An orange', p1: 'A lemon' },
  { a: '🍓', p: '🍌', an: 'strawberries', pn: 'bananas', a1: 'A strawberry', p1: 'A banana' },
];
const PROMPTS = [
  'Both tags are wrong! Tap a box to peek inside.',
  'All three tags are wrong. Which box should we peek in?',
  'New boxes! Can you fix them with just one peek?',
];
const CHEERS = ['Yes!', 'That’s right!', 'Good thinking!', 'Spot on!', 'Clever!'];
const DONE = ['All the tags are right now!', 'Every box has its true tag!', 'You fixed them all!'];
const RIBBON = ['#ff8fab', '#4cc9f0', '#9b5de5'];

const CSS = `
.a-wrong-labels{width:100%;max-width:640px;display:flex;flex-direction:column;align-items:center;gap:10px;margin:auto 0}
.a-wrong-labels .boxes{display:flex;gap:10px;justify-content:center;width:100%}
.a-wrong-labels .col{flex:1 1 0;min-width:0;max-width:190px;display:flex;flex-direction:column;align-items:center;border-radius:18px;padding:2px}
.a-wrong-labels .peekzone{height:60px;display:flex;align-items:flex-start;padding-top:2px;justify-content:center;font-size:clamp(1.5rem,6vw,2.1rem);white-space:nowrap;line-height:1}
.a-wrong-labels .peekzone .all{font-size:clamp(1.05rem,4.6vw,1.6rem)}
.a-wrong-labels .boxbtn{position:relative;display:block;width:100%;background:none;border:0;padding:0;cursor:pointer;min-height:56px;border-radius:14px}
.a-wrong-labels .boxbtn svg{display:block;width:100%;height:auto;overflow:visible}
.a-wrong-labels .lid{transition:transform .45s cubic-bezier(.3,1.4,.5,1);transform-box:view-box;transform-origin:4px 34px}
.a-wrong-labels .col.open .lid{transform:translateY(-2px) rotate(-9deg)}
.a-wrong-labels .oldtag{position:absolute;left:50%;top:64%;transform:translate(-50%,-50%);background:#fff8e7;border:2px solid #2b2d42;border-radius:8px;padding:1px 6px;font-size:clamp(.95rem,4.2vw,1.45rem);white-space:nowrap;line-height:1.2}
.a-wrong-labels .oldtag::after{content:'';position:absolute;left:-5px;right:-5px;top:48%;height:3px;border-radius:2px;background:rgba(43,45,66,.55);transform:rotate(-12deg)}
.a-wrong-labels .slot{width:100%;min-height:66px;margin-top:6px;border:3px dashed #c9b48a;border-radius:14px;display:grid;place-items:center;background:rgba(255,255,255,.55)}
.a-wrong-labels .slot .q{color:#c9b48a;font-weight:800;font-size:1.4rem}
.a-wrong-labels .tag{position:relative;min-width:58px;min-height:56px;padding:4px 10px 4px 20px;border:3px solid #2b2d42;border-radius:10px 18px 18px 10px;background:#fffdf5;font-size:clamp(1.2rem,5vw,1.6rem);box-shadow:0 3px 0 rgba(43,45,66,.15);white-space:nowrap;line-height:1}
.a-wrong-labels .tag::before{content:'';position:absolute;left:6px;top:50%;width:8px;height:8px;margin-top:-4px;border-radius:50%;border:2px solid #2b2d42;background:#fff8e7}
.a-wrong-labels .tray{display:flex;gap:12px;flex-wrap:wrap;justify-content:center;align-items:center;min-height:80px;padding:8px 12px;border-radius:20px;background:rgba(255,255,255,.7);border:3px solid #e8dfc8;transition:opacity .3s}
.a-wrong-labels .tray:empty{opacity:0}
.a-wrong-labels .tray.off{visibility:hidden;opacity:0}
.a-wrong-labels .maybe{display:flex;flex-direction:column;align-items:center;gap:4px;font-weight:800}
.a-wrong-labels .maybe:empty{display:none}
.a-wrong-labels .mrow{display:flex;gap:6px}
.a-wrong-labels .mini{min-width:52px;padding:4px 6px;text-align:center;border:2px solid #2b2d42;border-radius:8px;background:#e7b46e;font-size:1.15rem}
.a-wrong-labels .or{font-size:.9rem;opacity:.7}
.a-wrong-labels .fruit{display:inline-block}
@media (max-width:420px){.a-wrong-labels .boxes{gap:7px}.a-wrong-labels .tag{padding:4px 7px 4px 17px}}
`;

function boxSvg(color) {
  return h('svg', { viewBox: '0 0 120 96', 'aria-hidden': 'true', html: `
    <rect x="12" y="24" width="96" height="14" rx="3" fill="#6b4423"/>
    <rect x="10" y="30" width="100" height="62" rx="7" fill="#e7b46e" stroke="#2b2d42" stroke-width="3"/>
    <rect x="53" y="31.5" width="14" height="59" fill="${color}" opacity=".75"/>
    <path d="M16 40 h20 M84 40 h20" stroke="#c98f45" stroke-width="3" stroke-linecap="round"/>
    <g class="lid"><rect x="4" y="18" width="112" height="16" rx="5" fill="#d99a50" stroke="#2b2d42" stroke-width="3"/>
    <rect x="53" y="19.5" width="14" height="13" fill="${color}"/></g>` });
}

export default {
  id: 'wrong-labels',
  parentNote: 'Every tag is wrong, so a box can never hold what its tag says. The clever peek is the box tagged “mixed”: it must hold only one kind, so a single fruit tells you exactly what is inside, and the other two boxes follow by elimination. Ask “How do you know?” — children often trust the old tags, or think one fruit from a box cannot tell you much.',
  async start(api) {
    let alive = true; let ep = 0; let ri = 0; let R = null;
    const roundFruit = [FRUITS[0], FRUITS[0], pick(FRUITS)];
    api.css(CSS);
    const wrap = h('div', { class: 'a-wrong-labels' }); api.root.append(wrap);
    const live = (e) => alive && e === ep;
    const em = (k) => (k === 'm' ? R.fr.a + R.fr.p : R.fr[k]);
    const nm = (k) => (k === 'm' ? 'mixed' : R.fr[k + 'n']);
    const other = (k) => (k === 'a' ? 'p' : 'a');
    const retrigger = (el, cls) => { el.classList.remove(cls); void el.getBoundingClientRect(); el.classList.add(cls); };

    function build(arr, silent = false) {
      ep++;
      const e = ep;
      wrap.replaceChildren(); api.stage(ri, 3);
      const { labels, truth } = arr || arrangement(ri === 0 ? 2 : 3);
      R = { e, labels, truth, fr: roundFruit[ri], peeks: [], resolved: false, placed: 0, miss: 0, cols: [], tags: [], ctl: [], demo: false };
      const boxes = h('div', { class: 'boxes' });
      labels.forEach((L, i) => {
        const peek = h('div', { class: 'peekzone' });
        const btn = h('button', { class: 'boxbtn', 'aria-label': `Box with a ${nm(L)} tag. Peek inside.`, onclick: () => onPeek(i) },
          boxSvg(RIBBON[i]), h('span', { class: 'oldtag' }, em(L)));
        const slot = h('div', { class: 'slot' }, h('span', { class: 'q', 'aria-hidden': 'true' }, '?'));
        const col = h('div', { class: 'col', 'data-i': String(i) }, peek, btn, slot);
        R.cols.push({ col, peek, btn, slot, done: false }); boxes.append(col);
      });
      R.maybe = h('div', { class: 'maybe', 'aria-live': 'polite' });
      R.tray = h('div', { class: 'tray off', role: 'group', 'aria-label': 'New tags' });
      for (const k of shuffle(labels)) {
        const t = h('button', { class: 'tag', 'data-k': k, 'aria-label': `Tag: ${k === 'm' ? `mixed ${R.fr.an} and ${R.fr.pn}` : nm(k)}` }, em(k));
        R.tray.append(t); R.tags.push(t);
        R.ctl.push(drag(t, { dropSelector: '.a-wrong-labels .col', onDrop: (col, el) => onDropTag(col, el) }));
      }
      wrap.append(boxes, R.maybe, R.tray);
      if (!silent) api.prompt(PROMPTS[ri]);
      return e;
    }

    function doPeek(i, f) {
      R.peeks.push({ i, f });
      const c = R.cols[i];
      c.col.classList.add('open'); c.btn.classList.remove('glow');
      c.btn.setAttribute('aria-label', `Box with a ${nm(R.labels[i])} tag. ${f === 'a' ? R.fr.a1 : R.fr.p1} came out.`);
      const fr = h('span', { class: 'fruit' }, R.fr[f]);
      c.peek.replaceChildren(fr); retrigger(fr, 'hop'); sfx('pop');
    }

    function showMaybe(poss) {
      R.maybe.replaceChildren(h('div', {}, 'It could be…'),
        ...poss.flatMap((a, j) => [j ? h('div', { class: 'or' }, 'or') : null,
          h('div', { class: 'mrow' }, a.map((k) => h('span', { class: 'mini' }, em(k))))]).filter(Boolean));
    }

    function onPeek(i) {
      if (!R || R.demo) return;
      sfx('tap');
      if (R.resolved) { if (!R.cols[i].done) api.prompt('Drag a new tag onto this box.'); return; }
      if (R.peeks.some((p) => p.i === i)) { api.nudge('We peeked there. Try a different box.'); return; }
      const f = drawFrom(R.truth[i]);
      doPeek(i, f);
      const poss = possible(R.labels, R.peeks);
      const L = R.labels[i];
      if (poss.length === 1) {
        let msg = 'Now we know which box is which!';
        if (R.peeks.length === 1) {
          if (L === 'm') msg = `It says mixed, but that’s wrong. Only ${nm(f)}!`;
          else if (L === f) msg = `It says ${nm(L)}, but that’s wrong. So it’s mixed!`;
          else msg = `${f === 'a' ? R.fr.a1 : R.fr.p1}! So this is the ${nm(f)} box.`;
        }
        resolve(msg);
      } else {
        showMaybe(poss);
        api.nudge(`Only ${nm(f)}, or mixed? Not sure yet. Peek again!`);
        if (R.peeks.length >= 2) R.cols[R.labels.indexOf('m')].btn.classList.add('glow');
      }
    }

    async function resolve(msg) {
      const e = R.e;
      R.resolved = true; R.maybe.replaceChildren();
      R.cols.forEach((c) => c.btn.classList.remove('glow'));
      await api.cheer(msg);
      if (!live(e)) return;
      await sleep(350); if (!live(e)) return;
      R.tray.classList.remove('off');
      api.prompt('Now drag the new tags onto the right boxes.');
    }

    function onDropTag(col, el) {
      if (!R || !R.resolved || R.demo) return false;
      const i = +col.dataset.i; const k = el.dataset.k; const c = R.cols[i];
      if (c.done) { api.nudge('That box has its new tag already.'); return false; }
      if (R.truth[i] === k) { place(el, i); return true; }
      R.miss++; retrigger(c.col, 'shake');
      if (R.miss >= 2) { R.cols[R.truth.indexOf(k)].slot.classList.add('glow'); api.nudge('Try the glowing box!'); }
      else if (R.labels[i] === k) api.nudge('That was its old tag. Old tags are wrong!');
      else api.nudge('Hmm. Think about the fruit we found.');
      return false;
    }

    function place(el, i) {
      const c = R.cols[i];
      c.slot.replaceChildren(el);
      el.style.transition = 'none'; el.style.transform = ''; el._dragBase = { x: 0, y: 0 }; el._dragPos = null;
      R.ctl[R.tags.indexOf(el)].disable();
      c.done = true; R.miss = 0; R.placed++;
      R.cols.forEach((x) => x.slot.classList.remove('glow'));
      sfx('drop'); retrigger(el, 'hop');
      if (R.demo) return;
      if (R.placed === R.labels.length) finishRound(); else api.cheer(pick(CHEERS));
    }

    function openAll() {
      R.cols.forEach((c, i) => {
        const k = R.truth[i];
        c.col.classList.add('open');
        const s = h('span', { class: 'all' }, k === 'm' ? R.fr.a + R.fr.p + R.fr.a : R.fr[k].repeat(3));
        c.peek.replaceChildren(s); retrigger(s, 'hop');
      });
    }

    async function finishRound() {
      const e = R.e;
      openAll();
      await api.cheer(pick(DONE));
      if (!live(e)) return;
      await sleep(1600); if (!live(e)) return;
      ri++;
      if (ri < 3) build(); else api.finish();
    }

    // ---------- Watch: narrated reasoning on the same boxes ----------
    api.setDemo(async () => {
      const e = build({ labels: R.labels.slice(), truth: R.truth.slice() }, true);
      R.demo = true;
      const ok = () => live(e);
      const tell = async (t, ms = 700) => { await api.prompt(t); if (!ok()) return false; await sleep(ms + (settings.voice ? 0 : 800 + t.length * 22)); return ok(); };
      const moveTag = async (k, i) => {
        const t = R.tags.find((x) => x.dataset.k === k);
        R.cols[i].slot.classList.add('glow');
        await flyTo(t, R.cols[i].slot, { duration: 750 });
        if (!ok()) return false;
        place(t, i); return true;
      };
      const { labels, truth } = R;
      if (labels.length === 2) {
        if (!await tell('Both tags are wrong. Let’s peek in this box.')) return;
        R.cols[0].btn.classList.add('glow'); await sleep(500); if (!ok()) return;
        doPeek(0, truth[0]);
        if (!await tell(`It says ${nm(labels[0])}. That’s wrong, so it has ${nm(truth[0])}!`)) return;
        R.tray.classList.remove('off'); await sleep(300); if (!ok()) return;
        if (!await moveTag(truth[0], 0)) return;
        if (!await tell(`So the other box has ${nm(truth[1])}.`, 300)) return;
        if (!await moveTag(truth[1], 1)) return;
      } else {
        const m = labels.indexOf('m'); const X = truth[m]; const Y = other(X);
        const yi = labels.indexOf(Y); const xi = labels.indexOf(X);
        R.cols[m].btn.classList.add('glow');
        if (!await tell('Every tag is wrong. Peek in the box that says mixed!')) return;
        doPeek(m, X);
        if (!await tell(`It says mixed, but that’s wrong. So: only ${nm(X)}!`)) return;
        R.tray.classList.remove('off'); await sleep(300); if (!ok()) return;
        if (!await moveTag(X, m)) return;
        R.cols[yi].btn.classList.add('glow');
        if (!await tell(`This one says ${nm(Y)}. Wrong, and ${nm(X)} are taken. Mixed!`, 300)) return;
        R.cols[yi].btn.classList.remove('glow');
        if (!await moveTag('m', yi)) return;
        if (!await tell(`So the last box has only ${nm(Y)}.`, 300)) return;
        if (!await moveTag(Y, xi)) return;
      }
      openAll();
      if (!await tell('Now every tag is right!', 1400)) return;
      if (!await tell('Now you try, with new boxes!', 500)) return;
      build(null, false);
    });

    build();
    return { destroy() { alive = false; ep++; } };
  },
};
