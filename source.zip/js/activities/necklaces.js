// Necklace Makers — find every different row of beads (position matters).
// Round 1: 3 beads, 1 blue (3). Round 2: 4 beads, 2 blue (6). Round 3: 5 beads, 2 blue (10).
import { h, sleep, pick, sfx } from '../core.js';

const ROUNDS = [
  { n: 3, k: 1, expect: 3, prompt: 'Tap a bead to make it blue. Use one blue!' },
  { n: 4, k: 2, expect: 6, prompt: 'Four beads, two blue. Make every different necklace!' },
  { n: 5, k: 2, expect: 10, prompt: 'Five beads, two blue. How many different ones?' },
];
const FRIENDS = ['🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🐸', '🦔'];
const CHEERS = ['A new one!', 'Lovely, that one is new!', 'Ooh, another one!', 'Pretty! Keep going.', 'Yes, a new necklace!'];
const WORDS = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];
const word = (n) => WORDS[n] || String(n);

// Every pattern with k blue beads out of n, in the "systematic" order:
// first blue as far left as possible, the next blue slides along, then the first moves one step.
function combos(n, k) {
  const out = [];
  const rec = (start, chosen) => {
    if (chosen.length === k) { out.push(Array.from({ length: n }, (_, i) => (chosen.includes(i) ? 'B' : 'W')).join('')); return; }
    for (let i = start; i < n; i++) rec(i + 1, [...chosen, i]);
  };
  rec(0, []);
  return out;
}
const binom = (n, k) => { let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return r; };

const BLUE = 'radial-gradient(circle at 34% 30%,#bde9ff 0 12%,#3fb3e6 34%,#118ab2 62%,#0a5d7a)';
const WHITE = 'radial-gradient(circle at 34% 30%,#ffffff 0 30%,#f3eee3 62%,#d9d1bf)';

const CSS = `
.a-necklaces{width:100%;max-width:920px;display:flex;flex-direction:column;align-items:center;gap:12px;padding-bottom:8px}
.a-necklaces .goal{display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:center;font-weight:800;font-size:1.05rem;background:#fff;border:3px solid var(--ink);border-radius:18px;padding:6px 14px;transition:box-shadow .2s}
.a-necklaces .need{display:inline-flex;gap:5px;align-items:center}
.a-necklaces .need i{width:24px;height:24px;border-radius:50%;border:3px dashed #118ab2;display:inline-block;box-sizing:border-box;transition:background .2s}
.a-necklaces .need i.on{border:3px solid var(--ink);background:${BLUE}}
.a-necklaces .need i.over{border:3px solid var(--ink);background:${BLUE};opacity:.55;transform:scale(.85)}
.a-necklaces .bench{position:relative;display:flex;align-items:center;gap:3px;padding:6px 20px;width:100%;box-sizing:border-box;background:#fdf0dc;border:3px solid var(--ink);border-radius:999px}
.a-necklaces .bench::before,.a-necklaces .mini::before{content:'';position:absolute;left:10px;right:10px;top:50%;height:5px;margin-top:-2.5px;background:#b07d4f;border-radius:3px}
.a-necklaces .clasp{position:absolute;left:3px;top:50%;width:12px;height:12px;margin-top:-6px;border-radius:50%;border:3px solid #e0a800;box-sizing:border-box;background:#fdf0dc}
.a-necklaces .charm{position:absolute;right:3px;top:50%;transform:translateY(-52%);color:#ff5c8a;font-size:15px;line-height:1;font-weight:900}
.a-necklaces .bead{position:relative;flex:1 1 0;min-width:0;max-width:78px;aspect-ratio:1/1;border-radius:50%;border:3px solid var(--ink);padding:0;margin:0 auto;cursor:pointer;background:${WHITE};box-shadow:0 3px 0 rgba(43,45,66,.18);transition:transform .12s;-webkit-tap-highlight-color:transparent}
.a-necklaces .bead.blue{background:${BLUE}}
.a-necklaces .bead:active{transform:scale(.92)}
.a-necklaces .bead.tip{box-shadow:0 0 0 6px rgba(255,209,102,.95);animation:nk-pulse 1s ease-in-out infinite}
.a-necklaces .bead.tap{transform:scale(.88)}
@keyframes nk-pulse{50%{box-shadow:0 0 0 10px rgba(255,209,102,.55)}}
.a-necklaces .controls .btn{font-size:1.05rem}
.a-necklaces .hintcard{display:flex;align-items:center;gap:12px;flex-wrap:wrap;justify-content:center;background:#fffbe8;border:3px dashed var(--orange);border-radius:18px;padding:8px 12px;font-weight:800;max-width:100%;box-sizing:border-box}
.a-necklaces .hintcard[hidden]{display:none}
.a-necklaces .shelf{width:100%;box-sizing:border-box;background:linear-gradient(#f6e3c4,#efd5ab);border:3px solid var(--ink);border-radius:20px;padding:8px 10px 12px}
.a-necklaces .shelf.done{background:linear-gradient(#e2f9ec,#c8f1da)}
.a-necklaces .shelf-head{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;font-weight:900;margin:0 4px 8px}
.a-necklaces .shelf-head .count{background:#fff;border:3px solid var(--ink);border-radius:999px;padding:2px 12px;font-size:1.05rem}
.a-necklaces .shelf-row{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;min-height:40px}
.a-necklaces .shelf-row .empty-note{opacity:.6;font-weight:700;align-self:center}
.a-necklaces .mini{position:relative;display:inline-flex;align-items:center;gap:3px;padding:5px 17px;background:#fff;border:3px solid var(--ink);border-radius:999px;box-sizing:border-box}
.a-necklaces .mini i{position:relative;width:20px;height:20px;border-radius:50%;border:2px solid var(--ink);background:${WHITE};box-sizing:border-box;transition:background .25s}
.a-necklaces .mini i.b{background:${BLUE}}
.a-necklaces .mini .clasp{width:9px;height:9px;margin-top:-4.5px;border-width:2px;left:3px;background:#fff}
.a-necklaces .mini .charm{font-size:11px;right:3px}
.a-necklaces .mini.big{padding:7px 22px;gap:5px}
.a-necklaces .mini.big i{width:32px;height:32px;border-width:3px}
.a-necklaces .mini.empty{border-style:dashed;background:rgba(255,255,255,.45);color:rgba(43,45,66,.45);justify-content:center;font-weight:900}
.a-necklaces .mini.empty::before{display:none}
.a-necklaces .mini.new{animation:nk-new .6s cubic-bezier(.3,1.5,.5,1)}
@keyframes nk-new{0%{transform:scale(.6)}60%{transform:scale(1.15)}}
.a-necklaces .nk-hand{position:fixed;left:0;top:0;font-size:42px;line-height:1;pointer-events:none;z-index:46;transition:transform .3s cubic-bezier(.4,.1,.2,1);filter:drop-shadow(0 3px 2px rgba(0,0,0,.25))}
.a-necklaces .btn.press{transform:translateY(3px);box-shadow:none}
@media (max-width:420px){.a-necklaces .mini i{width:18px;height:18px}.a-necklaces .mini.big i{width:28px;height:28px}.a-necklaces .controls .btn{font-size:.98rem;padding:.5em .9em}}
`;

function mini(pat, big = false) {
  const blues = [...pat].map((c, i) => (c === 'B' ? i + 1 : 0)).filter(Boolean);
  return h('div', { class: 'mini' + (big ? ' big' : ''), role: 'img', 'aria-label': `Necklace with blue beads at places ${blues.join(' and ')}` },
    h('span', { class: 'clasp' }), [...pat].map((c) => h('i', { class: c === 'B' ? 'b' : '' })), h('span', { class: 'charm' }, '♥'));
}

export default {
  id: 'necklaces',
  parentNote: 'Each necklace is a row of beads and the order matters: blue at the clasp end and blue at the heart end are two different necklaces. Ask "How do you know you have them all?" — children usually stop when they cannot think of more, not when there are no more. The trick is a plan: keep the first blue bead still and slide the other one along, then move the first one a step; with 5 beads and 2 blue there are exactly 10.',
  async start(api) {
    let alive = true; let token = 0;
    const timers = new Set();
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (alive) fn(); }, ms); timers.add(t); };
    // speak/show a line, but never wait longer than the line needs (speech may be missing or off)
    const talk = (text, fn = api.prompt) => Promise.race([fn(text), sleep(900 + text.length * 60)]);

    api.css(CSS);
    const wrap = h('div', { class: 'a-necklaces' });
    api.root.append(wrap);
    const goal = h('div', { class: 'goal' });
    const bench = h('div', { class: 'bench', role: 'group', 'aria-label': 'Your necklace' });
    const btnClear = h('button', { class: 'btn', type: 'button', 'aria-label': 'Make all beads white' }, '⚪ Clear');
    const btnAdd = h('button', { class: 'btn primary', type: 'button' }, '➕ Add to shelf');
    const btnHint = h('button', { class: 'btn', type: 'button', 'aria-label': 'Hint: show me a plan' }, '💡 Hint');
    const btnNext = h('button', { class: 'btn primary', type: 'button', hidden: true }, 'Next ➜');
    const controls = h('div', { class: 'act-row controls' }, btnClear, btnAdd, btnHint, btnNext);
    const hintCard = h('div', { class: 'hintcard', hidden: true, 'aria-live': 'polite' });
    const shelfTitle = h('span', {});
    const countEl = h('span', { class: 'count' });
    const shelfRow = h('div', { class: 'shelf-row' });
    const shelf = h('section', { class: 'shelf', 'aria-label': 'Shelf of necklaces' }, h('div', { class: 'shelf-head' }, shelfTitle, countEl), shelfRow);
    wrap.append(goal, bench, controls, hintCard, shelf);

    let round = 0; let R = ROUNDS[0]; let all = []; let found = []; const items = new Map();
    let beads = []; let state = []; let busy = false; let wrongRow = 0; let revealed = false; let needEl = null;

    const pattern = () => state.map((b) => (b ? 'B' : 'W')).join('');
    const blueCount = () => state.filter(Boolean).length;
    const firstMissing = () => all.find((p) => !found.includes(p));
    function restartAnim(el, cls, ms) { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); later(() => el.classList.remove(cls), ms); }

    function updateNeed() {
      const b = blueCount();
      const dots = [];
      for (let i = 0; i < R.k; i++) dots.push(h('i', { class: i < b ? 'on' : '' }));
      for (let i = R.k; i < b; i++) dots.push(h('i', { class: 'over' }));
      needEl.replaceChildren(...dots);
    }
    function paintBead(i) {
      const el = beads[i];
      el.classList.toggle('blue', state[i]);
      el.setAttribute('aria-pressed', String(state[i]));
      el.setAttribute('aria-label', `Bead ${i + 1}, ${state[i] ? 'blue' : 'white'}`);
    }
    function toggle(i) { state[i] = !state[i]; paintBead(i); updateNeed(); sfx(state[i] ? 'pop' : 'tap'); }
    function clearTips() { beads.forEach((b) => b.classList.remove('tip')); }

    function renderBench() {
      beads = state.map((_, i) => h('button', { class: 'bead', type: 'button', onclick: () => { if (!busy) toggle(i); } }));
      bench.style.maxWidth = (R.n * 82 + 46) + 'px';
      bench.replaceChildren(h('span', { class: 'clasp', 'aria-hidden': 'true' }), ...beads, h('span', { class: 'charm', 'aria-hidden': 'true' }, '♥'));
      beads.forEach((_, i) => paintBead(i));
    }
    function renderShelf() {
      const kids = found.map((p) => items.get(p));
      if (revealed) for (let i = found.length; i < all.length; i++) kids.push(h('div', { class: 'mini empty', 'aria-hidden': 'true' }, '?'));
      if (!kids.length) kids.push(h('span', { class: 'empty-note' }, 'Your necklaces go here.'));
      shelfRow.replaceChildren(...kids);
      countEl.textContent = revealed ? `Found ${found.length} of ${all.length}` : `Found ${found.length}`;
    }

    // a copy of the shelf necklace flies from the workbench into its place
    function flyInto(fromEl, toEl, ms = 480) {
      toEl.scrollIntoView({ block: 'nearest' });
      const a = fromEl.getBoundingClientRect(); const b = toEl.getBoundingClientRect();
      const c = toEl.cloneNode(true);
      Object.assign(c.style, { position: 'fixed', left: b.left + 'px', top: b.top + 'px', width: b.width + 'px', height: b.height + 'px', margin: '0', zIndex: '45', pointerEvents: 'none', visibility: 'visible', transition: 'none' });
      const s = Math.max(1, Math.min(a.width / b.width, 2.4));
      c.style.transform = `translate(${a.left + a.width / 2 - (b.left + b.width / 2)}px, ${a.top + a.height / 2 - (b.top + b.height / 2)}px) scale(${s})`;
      wrap.append(c);
      c.getBoundingClientRect();
      c.style.transition = `transform ${ms}ms cubic-bezier(.4,.1,.2,1)`;
      c.style.transform = 'none';
      return sleep(ms).then(() => c.remove());
    }

    function showTip() {
      const m = firstMissing(); if (!m) return;
      clearTips();
      [...m].forEach((c, i) => { if (c === 'B') beads[i].classList.add('tip'); });
    }
    function wrong(msg, tipMsg) {
      wrongRow++;
      restartAnim(bench, 'shake', 450);
      if (wrongRow >= 2) { showTip(); api.nudge(tipMsg); } else api.nudge(msg);
    }

    async function tryAdd(fromDemo = false) {
      if (busy && !fromDemo) return;
      const t = token; const b = blueCount(); const pat = pattern();
      if (b !== R.k) {
        restartAnim(goal, 'glow', 1200);
        const msg = b < R.k
          ? (R.k === 1 ? 'Make one bead blue first.' : `This needs ${word(R.k)} blue beads. Tap ${word(R.k - b)} more.`)
          : `Only ${word(R.k)} blue, please. Make ${word(b - R.k)} white again.`;
        wrong(msg, `Use ${word(R.k)} blue. Try the shining spots!`);
        return;
      }
      if (found.includes(pat)) {
        const twin = items.get(pat);
        twin.scrollIntoView({ block: 'nearest' });
        twin.classList.add('glow'); restartAnim(twin, 'hop', 600); later(() => twin.classList.remove('glow'), 1800);
        wrong('You already made that one! Try moving one blue bead.', 'You made that one. Try the shining spots!');
        return;
      }
      wrongRow = 0; clearTips(); hintCard.hidden = true;
      const justRevealed = !revealed && found.length + 1 >= Math.min(3, all.length);
      found.push(pat);
      const el = mini(pat); items.set(pat, el);
      if (justRevealed) revealed = true;
      renderShelf();
      el.style.visibility = 'hidden';
      busy = true; sfx('whoosh');
      restartAnim(btnAdd, 'press', 150);
      await flyInto(bench, el);
      if (!alive || t !== token) return;
      el.style.visibility = ''; restartAnim(el, 'new', 650); sfx('drop');
      if (found.length === all.length) { await roundDone(fromDemo); return; }
      if (!fromDemo) {
        busy = false;
        api.cheer(justRevealed ? `Great! There are ${word(all.length)} different ones. Find them all!` : pick(CHEERS));
      }
    }

    async function roundDone(fromDemo) {
      const t = token; busy = true;
      btnClear.hidden = btnAdd.hidden = btnHint.hidden = true;
      api.cheer(round < 2 ? `You found all ${word(all.length)}! Every single one!` : 'All ten! You are a super necklace maker!');
      await sleep(1100);
      if (!alive || t !== token) return;
      // line them up in the plan's order: no gaps, no repeats
      found = all.slice(); renderShelf(); shelf.classList.add('done'); sfx('flip');
      found.forEach((p, i) => later(() => { if (t === token) restartAnim(items.get(p), 'hop', 520); }, i * 110));
      if (fromDemo) return;
      await sleep(900 + all.length * 110);
      if (!alive || t !== token) return;
      btnNext.textContent = round < 2 ? 'Next necklaces ➜' : 'All done! 🎉';
      btnNext.hidden = false; btnNext.disabled = false;
      api.prompt(round < 2 ? 'Look! In order, from left to right. Tap Next.' : 'Look! All ten in order. No gaps!');
    }

    async function showHint() {
      if (busy) return;
      const t = token; busy = true;
      const ghost = mini(all[0], true); const label = h('span', {}, '');
      hintCard.replaceChildren(h('span', { 'aria-hidden': 'true' }, '💡'), ghost, label); hintCard.hidden = false;
      hintCard.scrollIntoView({ block: 'nearest' });
      await talk(R.k === 1 ? 'A plan: blue at the start, then slide it along.' : 'A plan: keep one blue still, slide the other along.');
      if (!alive || t !== token) return;
      for (const p of all) {
        [...ghost.querySelectorAll('i')].forEach((el, i) => el.classList.toggle('b', p[i] === 'B'));
        sfx('tick');
        await sleep(700);
        if (!alive || t !== token) return;
        if (found.includes(p)) {
          label.textContent = '✓ on the shelf';
          const tw = items.get(p); tw.classList.add('glow');
          await sleep(550);
          tw.classList.remove('glow');
          if (!alive || t !== token) return;
        } else {
          label.textContent = 'Not on the shelf yet!';
          ghost.classList.add('glow');
          api.prompt('This one is missing. Can you make it?');
          break;
        }
      }
      busy = false;
    }

    function startRound(i, quiet = false) {
      token++; round = i; R = ROUNDS[i];
      all = combos(R.n, R.k);
      if (all.length !== R.expect || all.length !== binom(R.n, R.k)) throw new Error('necklace count mismatch');
      found = []; items.clear(); state = Array(R.n).fill(false); busy = false; wrongRow = 0; revealed = false;
      api.stage(i, ROUNDS.length);
      needEl = h('span', { class: 'need', 'aria-hidden': 'true' });
      goal.replaceChildren(h('span', {}, `${word(R.n)[0].toUpperCase() + word(R.n).slice(1)} beads, use ${word(R.k)} blue:`), needEl);
      renderBench(); updateNeed();
      shelfTitle.textContent = `${pick(FRIENDS)} Necklace shelf`;
      shelf.classList.remove('done'); hintCard.hidden = true;
      btnClear.hidden = btnAdd.hidden = btnHint.hidden = false; btnNext.hidden = true;
      renderShelf();
      if (!quiet) api.prompt(R.prompt);
    }

    btnClear.addEventListener('click', () => { if (busy) return; state.fill(false); beads.forEach((_, i) => paintBead(i)); updateNeed(); sfx('tap'); });
    btnAdd.addEventListener('click', () => tryAdd(false));
    btnHint.addEventListener('click', () => showHint());
    btnNext.addEventListener('click', () => {
      if (btnNext.disabled) return;
      btnNext.disabled = true; sfx('tap');
      if (round < ROUNDS.length - 1) startRound(round + 1); else api.finish();
    });

    // Watch: make every necklace in the plan's order, sliding the blue beads along.
    api.setDemo(async () => {
      startRound(round, true);
      const t = token; busy = true;
      const ok = () => alive && t === token;
      const hand = h('div', { class: 'nk-hand', 'aria-hidden': 'true' }, '👆');
      wrap.append(hand);
      const moveHand = async (el, ms = 300) => {
        const r = el.getBoundingClientRect();
        hand.style.transitionDuration = ms + 'ms';
        hand.style.transform = `translate(${r.left + r.width / 2 - 14}px, ${r.top + r.height / 2 - 4}px)`;
        await sleep(ms);
      };
      try {
        bench.scrollIntoView({ block: 'nearest' });
        const r0 = bench.getBoundingClientRect();
        hand.style.transition = 'none';
        hand.style.transform = `translate(${r0.left + r0.width / 2}px, ${r0.bottom + 30}px)`;
        hand.getBoundingClientRect(); hand.style.transition = '';
        await talk('Watch me make them all, in order.');
        if (!ok()) return;
        for (let idx = 0; idx < all.length; idx++) {
          const p = all[idx]; const prev = idx ? all[idx - 1] : null;
          if (idx === 0) await talk(R.k === 1 ? 'Blue at the very start.' : 'Two blue at the very start.');
          else if (R.k === 2 && prev.indexOf('B') !== p.indexOf('B')) await talk('Now the first blue moves one step.');
          else if (idx === 1 || (R.k === 2 && all[idx - 2] && all[idx - 2].indexOf('B') !== prev.indexOf('B'))) await talk('Slide it one step along.');
          if (!ok()) return;
          const offs = []; const ons = [];
          state.forEach((s, i) => { if (s && p[i] === 'W') offs.push(i); if (!s && p[i] === 'B') ons.push(i); });
          for (const i of [...offs, ...ons]) {
            await moveHand(beads[i]);
            if (!ok()) return;
            beads[i].classList.add('tap'); toggle(i);
            await sleep(170);
            beads[i].classList.remove('tap');
          }
          await moveHand(btnAdd, 280);
          if (!ok()) return;
          await tryAdd(true);
          if (!ok()) return;
          await sleep(220);
        }
        hand.style.opacity = '0';
        await sleep(1600 + all.length * 110);
        if (!ok()) return;
        startRound(round, true);
        api.prompt('Your turn! Can you find them all?');
      } finally { hand.remove(); }
    });

    startRound(0);
    return { destroy() { alive = false; token++; timers.forEach(clearTimeout); timers.clear(); } };
  },
};
