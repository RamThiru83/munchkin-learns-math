// Shared helpers for Munchkin Learns Math. Plain ES module, no dependencies.

// ---------- tiny DOM helper ----------
export function h(tag, attrs = {}, ...children) {
  const isSvg = ['svg','g','path','circle','rect','line','polygon','polyline','ellipse','text','defs','use','clipPath','linearGradient','stop','animate','animateTransform'].includes(tag);
  const el = isSvg ? document.createElementNS('http://www.w3.org/2000/svg', tag) : document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === 'class') el.setAttribute('class', v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'html') el.innerHTML = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const rand = (n) => Math.floor(Math.random() * n);
export const pick = (arr) => arr[rand(arr.length)];
export function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = rand(i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
export const range = (n, start = 0) => Array.from({ length: n }, (_, i) => i + start);

// ---------- safe storage ----------
export const store = {
  get(k, d) { try { const v = localStorage.getItem('nilaa:' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('nilaa:' + k, JSON.stringify(v)); } catch { /* ignore */ } },
};

// ---------- sound effects (WebAudio, no files) ----------
let actx = null;
export const settings = { sound: store.get('sound', true), voice: store.get('voice', true) };
export function setSound(on) { settings.sound = on; store.set('sound', on); }
export function setVoiceOn(on) { settings.voice = on; store.set('voice', on); if (!on) stopSpeaking(); }

function ctx() {
  if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch { actx = null; } }
  if (actx && actx.state === 'suspended') actx.resume().catch(() => {});
  return actx;
}
function tone(freq, dur = 0.15, { type = 'sine', vol = 0.12, delay = 0, slideTo = null } = {}) {
  const a = ctx(); if (!a) return;
  const t0 = a.currentTime + delay;
  const o = a.createOscillator(); const g = a.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t0);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g).connect(a.destination); o.start(t0); o.stop(t0 + dur + 0.05);
}
// names: tap, pop, good, oops, win, whoosh, step, drop, flip, tick
export function sfx(name) {
  if (!settings.sound) return;
  switch (name) {
    case 'tap': tone(520, 0.07, { type: 'triangle' }); break;
    case 'pop': tone(700, 0.09, { type: 'sine', slideTo: 1000 }); break;
    case 'drop': tone(300, 0.1, { type: 'triangle', slideTo: 200 }); break;
    case 'step': tone(260, 0.06, { type: 'square', vol: 0.05 }); break;
    case 'tick': tone(900, 0.04, { type: 'square', vol: 0.04 }); break;
    case 'flip': tone(400, 0.12, { type: 'triangle', slideTo: 700 }); break;
    case 'whoosh': tone(900, 0.25, { type: 'sine', vol: 0.06, slideTo: 200 }); break;
    case 'good': tone(660, 0.12, { type: 'triangle' }); tone(880, 0.16, { type: 'triangle', delay: 0.1 }); break;
    case 'oops': tone(330, 0.16, { type: 'sine', vol: 0.09, slideTo: 260 }); break;
    case 'win': [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.2, { type: 'triangle', delay: i * 0.11 })); break;
    default: tone(500, 0.08);
  }
}

// ---------- speech ----------
let voiceCache = null;
function chooseVoice() {
  if (!('speechSynthesis' in window)) return null;
  const vs = speechSynthesis.getVoices();
  if (!vs.length) return null;
  if (voiceCache) return voiceCache;
  const prefs = [/en[-_]IN/i, /en[-_]GB/i, /en[-_]US/i, /^en/i];
  for (const p of prefs) {
    const v = vs.find((x) => p.test(x.lang) && /female|samantha|karen|veena|google|serena|moira|kate|zira/i.test(x.name)) || vs.find((x) => p.test(x.lang));
    if (v) { voiceCache = v; return v; }
  }
  return null;
}
if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = () => { voiceCache = null; };
export function stopSpeaking() { try { speechSynthesis.cancel(); } catch { /* ignore */ } }
// Returns a promise that resolves when speech ends (or immediately when voice is off).
export function say(text, { cancel = true } = {}) {
  return new Promise((resolve) => {
    if (!settings.voice || !('speechSynthesis' in window) || !text) return resolve();
    try {
      if (cancel) speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(String(text).replace(/[\u{1F300}-\u{1FAFF}☀-➿]/gu, ''));
      const v = chooseVoice(); if (v) { u.voice = v; u.lang = v.lang; } else u.lang = 'en-IN';
      u.rate = 0.9; u.pitch = 1.15; u.volume = 1;
      let done = false; const fin = () => { if (!done) { done = true; resolve(); } };
      u.onend = fin; u.onerror = fin;
      setTimeout(fin, 12000 + text.length * 80);
      speechSynthesis.speak(u);
    } catch { resolve(); }
  });
}

// ---------- confetti ----------
export function confetti(root = document.body, n = 36) {
  const colors = ['#ff8fab', '#ffd166', '#06d6a0', '#4cc9f0', '#b794f4', '#ff9f68'];
  const layer = h('div', { class: 'confetti-layer', 'aria-hidden': 'true' });
  for (let i = 0; i < n; i++) {
    const p = h('i', { style: {
      left: Math.random() * 100 + '%', background: colors[i % colors.length],
      animationDelay: Math.random() * 0.35 + 's', animationDuration: 1.4 + Math.random() * 1.2 + 's',
      transform: `rotate(${rand(360)}deg)`,
    } });
    layer.append(p);
  }
  root.append(layer);
  setTimeout(() => layer.remove(), 3200);
}

// ---------- pointer drag helper ----------
// drag(el, { dropSelector, onDrop(dropEl, el)=>bool|void, onStart, onEnd, bounds })
// - Works with mouse and touch (pointer events). The element follows the pointer via CSS transform.
// - On release, finds the element under the pointer matching `dropSelector`.
// - If onDrop returns false (or nothing matched) the element glides back to where it started.
// - `el.classList.add('dragging')` while held. Returns an object with `disable()` / `enable()`.
export function drag(el, opts = {}) {
  const { dropSelector = null, onDrop = null, onStart = null, onEnd = null, snapBack = true } = opts;
  let state = null; let enabled = true;
  el.style.touchAction = 'none'; el.style.cursor = 'grab'; el.style.userSelect = 'none';
  const down = (e) => {
    if (!enabled || (e.button != null && e.button > 0)) return;
    e.preventDefault();
    const base = el._dragBase || { x: 0, y: 0 };
    state = { sx: e.clientX, sy: e.clientY, bx: base.x, by: base.y, moved: false };
    el.setPointerCapture?.(e.pointerId);
    el.classList.add('dragging'); el.style.transition = 'none'; el.style.zIndex = 1000;
    ctx(); onStart?.(el, e);
  };
  const move = (e) => {
    if (!state) return;
    const dx = e.clientX - state.sx; const dy = e.clientY - state.sy;
    if (Math.abs(dx) + Math.abs(dy) > 4) state.moved = true;
    el.style.transform = `translate(${state.bx + dx}px, ${state.by + dy}px) scale(1.08)`;
    el._dragPos = { x: state.bx + dx, y: state.by + dy };
  };
  const up = (e) => {
    if (!state) return;
    const st = state; state = null;
    el.classList.remove('dragging'); el.releasePointerCapture?.(e.pointerId);
    let target = null;
    if (dropSelector) {
      const prev = el.style.pointerEvents; el.style.pointerEvents = 'none';
      const under = document.elementFromPoint(e.clientX, e.clientY);
      el.style.pointerEvents = prev;
      target = under ? under.closest(dropSelector) : null;
    }
    let ok = true;
    if (onDrop && (target || !dropSelector)) { const r = onDrop(target, el, st.moved); if (r === false) ok = false; }
    else if (dropSelector) ok = false;
    if (!ok && snapBack) glideBack(el);
    else { el.style.zIndex = ''; if (el._dragBase === undefined) el._dragBase = null; }
    onEnd?.(el, ok);
  };
  el.addEventListener('pointerdown', down);
  el.addEventListener('pointermove', move);
  el.addEventListener('pointerup', up);
  el.addEventListener('pointercancel', up);
  return { disable() { enabled = false; el.style.cursor = 'default'; }, enable() { enabled = true; el.style.cursor = 'grab'; } };
}
export function glideBack(el) {
  const base = el._dragBase || { x: 0, y: 0 };
  el.style.transition = 'transform .28s cubic-bezier(.3,1.4,.5,1)';
  el.style.transform = `translate(${base.x}px, ${base.y}px)`;
  el._dragPos = null;
  setTimeout(() => { el.style.zIndex = ''; el.style.transition = ''; }, 300);
}
// Move an element so its centre lands on the centre of `target` (both are in the page). Animated.
export function flyTo(el, target, { duration = 400, offset = { x: 0, y: 0 } } = {}) {
  const a = el.getBoundingClientRect(); const b = target.getBoundingClientRect();
  const base = el._dragPos || el._dragBase || { x: 0, y: 0 };
  const nx = base.x + (b.left + b.width / 2 - (a.left + a.width / 2)) + offset.x;
  const ny = base.y + (b.top + b.height / 2 - (a.top + a.height / 2)) + offset.y;
  el.style.transition = `transform ${duration}ms cubic-bezier(.4,.1,.2,1)`;
  el.style.transform = `translate(${nx}px, ${ny}px)`;
  el._dragBase = { x: nx, y: ny }; el._dragPos = null;
  return sleep(duration);
}

// ---------- reusable SVG bits ----------
export const COLORS = {
  red: '#ef476f', yellow: '#ffd166', green: '#06d6a0', blue: '#118ab2', purple: '#9b5de5',
  orange: '#ff9f1c', pink: '#ff8fab', sky: '#4cc9f0', ink: '#2b2d42', cream: '#fff8e7',
};
