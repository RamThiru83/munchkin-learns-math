#!/usr/bin/env python3
"""Resume test: python3 tests/resume.py [id ...]   (server on :8765 or BASE env)
For each activity and each saved round r in 1..n-1: pretend the child left on round r, open the game,
check the welcome-back card, tap "Carry on", check the game really starts on round r (the yellow 'now' dot),
run the Watch demo on that round, and check no console errors. Also checks "Start from round 1"."""
import sys, re, os, time, json
from playwright.sync_api import sync_playwright
BASE = os.environ.get('BASE', 'http://localhost:8765/')
root = os.path.dirname(os.path.abspath(__file__))
src = open(f'{root}/../js/registry.js').read()
ids = re.findall(r"id: '([^']+)', level", src)
want = [a for a in sys.argv[1:] if not a.startswith('-')] or ids
N = 5
bad = 0
NOW = "Array.from(document.querySelectorAll('.dots .dot')).findIndex(d => d.classList.contains('now'))"
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get('CHROME', '/opt/pw-browsers/chromium'), args=['--no-sandbox'])
    for vp in [(1024, 768), (390, 780)]:
        ctx = b.new_context(viewport={'width': vp[0], 'height': vp[1]}, has_touch=vp[0] < 500)
        tag = 'd' if vp[0] > 500 else 'm'
        for i in want:
            errs = []
            for r in range(1, N):
                pg = ctx.new_page()
                pg.on('console', lambda m, errs=errs: errs.append(m.text) if m.type == 'error' else None)
                pg.on('pageerror', lambda e, errs=errs: errs.append('PAGEERROR ' + str(e)))
                pg.goto(BASE + '#/')
                pg.evaluate(f"localStorage.setItem('nilaa:resume', JSON.stringify({{'{i}': {{r: {r}, n: {N}}}}}))")
                pg.goto(f'{BASE}?r={r}#/play/{i}'); pg.reload(); pg.wait_for_timeout(500)
                if not pg.locator('[data-resume=continue]').count():
                    errs.append(f'r{r}: no welcome-back card'); pg.close(); continue
                pg.click('[data-resume=continue]'); pg.wait_for_timeout(1200)
                now = pg.evaluate(NOW)
                if now != r: errs.append(f'r{r}: game started on round {now + 1} not {r + 1}')
                saved = pg.evaluate("JSON.parse(localStorage.getItem('nilaa:resume')||'{}')")
                if saved.get(i, {}).get('r') != r: errs.append(f'r{r}: saved state became {saved.get(i)}')
                if r in (1, N - 1) and vp[0] > 500 or r == N - 1:
                    w = pg.locator('button.watch')
                    if w.count() and w.first.is_visible():
                        w.first.click(); t0 = time.time()
                        while time.time() - t0 < 150:
                            pg.wait_for_timeout(500)
                            if not pg.locator('.stage.demo-running').count(): break
                        else: errs.append(f'r{r}: demo did not finish')
                        if pg.evaluate(NOW) < r and not pg.locator('.overlay').count():
                            errs.append(f'r{r}: after demo the round went back to {pg.evaluate(NOW) + 1}')
                    pg.screenshot(path=f'{root}/shots/{i}.resume{r}.{tag}.png')
                if pg.evaluate("document.documentElement.scrollWidth > innerWidth + 2"): errs.append(f'r{r}: horizontal overflow')
                pg.close()
            # restart option
            pg = ctx.new_page()
            pg.goto(BASE + '#/')
            pg.evaluate(f"localStorage.setItem('nilaa:resume', JSON.stringify({{'{i}': {{r: 3, n: {N}}}}}))")
            pg.goto(f'{BASE}?x=1#/play/{i}'); pg.reload(); pg.wait_for_timeout(500)
            if pg.locator('[data-resume=restart]').count():
                pg.click('[data-resume=restart]'); pg.wait_for_timeout(1000)
                if pg.evaluate(NOW) != 0: errs.append('restart did not go to round 1')
            pg.close()
            print(('FAIL ' if errs else 'ok   ') + f'{i} [{tag}]', *errs[:5]); bad += bool(errs)
        ctx.close()
    b.close()
sys.exit(1 if bad else 0)
