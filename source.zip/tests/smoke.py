#!/usr/bin/env python3
"""Smoke test: python3 tests/smoke.py [id ...]   (server must run on :8765, see serve.sh)
For each activity: load, record console/page errors, screenshot (tests/shots/<id>.png),
click Watch (if present) and wait for it to finish, screenshot again, then click Again."""
import sys, re, os, time
from playwright.sync_api import sync_playwright
BASE = os.environ.get('BASE', 'http://localhost:8765/')
root = os.path.dirname(os.path.abspath(__file__))
os.makedirs(f'{root}/shots', exist_ok=True)
src = open(f'{root}/../js/registry.js').read()
ids = re.findall(r"id: '([^']+)', level", src)
want = sys.argv[1:] or ids
bad = 0
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get('CHROME', '/opt/pw-browsers/chromium'), args=['--no-sandbox'])
    for vp in [(1024, 768), (390, 780)]:
        ctx = b.new_context(viewport={'width': vp[0], 'height': vp[1]}, has_touch=vp[0] < 500)
        for i in want:
            pg = ctx.new_page(); errs = []
            pg.on('console', lambda m, errs=errs: errs.append(m.text) if m.type == 'error' else None)
            pg.on('pageerror', lambda e, errs=errs: errs.append('PAGEERROR ' + str(e)))
            pg.goto(f'{BASE}#/play/{i}'); pg.wait_for_timeout(700)
            tag = 'd' if vp[0] > 500 else 'm'
            pg.screenshot(path=f'{root}/shots/{i}.{tag}.png')
            w = pg.locator('button.watch')
            if w.count() and w.first.is_visible():
                w.first.click(); t0 = time.time()
                while time.time() - t0 < 90:
                    pg.wait_for_timeout(500)
                    if not pg.locator('.stage.demo-running').count(): break
                else: errs.append('DEMO did not finish in 90s')
                pg.screenshot(path=f'{root}/shots/{i}.{tag}.demo.png')
            else: errs.append('NOTE: no Watch demo registered')
            ov = pg.evaluate("document.documentElement.scrollWidth > innerWidth + 2")
            if ov: errs.append('horizontal overflow at ' + str(vp))
            hard = [e for e in errs if not e.startswith('NOTE')]
            print(('FAIL ' if hard else 'ok   ') + f'{i} [{tag}]', *errs[:4]); bad += bool(hard)
            pg.close()
        ctx.close()
    b.close()
sys.exit(1 if bad else 0)
