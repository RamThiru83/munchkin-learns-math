#!/bin/sh
# Builds dist/index.html — the whole site in ONE self-contained file (needs esbuild: npm i esbuild).
set -e
cd "$(dirname "$0")"
mkdir -p dist
ESB=${ESBUILD:-npx esbuild}
$ESB js/app.js --bundle --minify --format=iife --target=es2020 --outfile=dist/app.js --log-level=warning
python3 - <<'PY'
html=open('index.html').read()
css=open('css/style.css').read()
js=open('dist/app.js').read().replace('</script','<\\/script')
html=html.replace('<link rel="stylesheet" href="css/style.css">','<style>'+css+'</style>')
html=html.replace('<script type="module" src="js/app.js"></script>','<script>'+js+'</script>')
open('dist/index.html','w').write(html)
print('dist/index.html', len(html)//1024, 'KB')
PY
rm -f dist/app.js
